<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['uid'])) {
    header('Location: login.php');
    exit;
}

// Get the user ID from the session
$uid = $_SESSION['uid'];

// Connect to database
$conn = mysqli_connect("localhost", "root", "", "foods");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty!";
    exit();
}

// Fetch the cart items from the session
$cartItems = $_SESSION['cart'];

// Calculate the total amount
$totalAmount = 0;
foreach ($cartItems as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

// Get user data from the database
$query = "SELECT * FROM user WHERE id = '$uid'";
$result = mysqli_query($conn, $query);
if ($result) {
    $customer_data = mysqli_fetch_assoc($result);
} else {
    echo "Error: " . mysqli_error($conn);
}

// Insert records into the payments table upon order submission
if (isset($_POST['order'])) {
    // Get payment method from POST request
    $payment_method = $_POST['payment_method'];
    $order_details = '';

    foreach ($_SESSION['cart'] as $item) {
        if (isset($item['name'], $item['quantity'], $item['price'])) {
            // Format item data as "item_name->quantity->price"
            $order_details .= $item['name'] . '->' . $item['quantity'] . '->' . $item['price'] . ', ';
        }
    }
    // Prepare order details as a serialized array
    //$order_details = serialize($cartItems); // Serialize the array to save in DB

    // Insert payment details into the payments table
    $stmt = $conn->prepare("INSERT INTO payments (user_id, order_details, payment_method, total_amount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("issd", $uid, $order_details, $payment_method, $totalAmount);

    // Execute and check if successful
    if ($stmt->execute()) {
        echo "Order placed successfully!";
        // Clear the cart
        // unset($_SESSION['cart']);
        // Redirect to a confirmation page or order summary
        header('Location: bill.php');
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Calculate subtotal and total for the cart
$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <style>
       /* Reset default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    color: #333;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

/* Account Details */
.account-details, .cart-summary, .payment-details {
    margin-bottom: 30px;
    padding: 20px;
    border-radius: 10px;
    background-color: #f9f9f9;
}

h2 {
    color: #2c3e50;
    margin-bottom: 20px;
    font-size: 26px;
    border-bottom: 2px solid #3498db;
    padding-bottom: 10px;
}

p {
    font-size: 18px;
    line-height: 1.6;
    color: #555;
}

button {
    background-color: #3498db;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #2980b9;
}

/* Table styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

table th, table td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #3498db;
    color: white;
    text-transform: uppercase;
    font-weight: bold;
}

td {
    background-color: #f9f9f9;
}

/* Payment Method Styling */
.payment-details p {
    font-size: 18px;
    margin-bottom: 15px;
    color: #2c3e50;
}

label {
    font-size: 18px;
    color: #555;
    margin-left: 10px;
}

input[type="radio"] {
    margin-right: 10px;
}

/* Amount payable */
.payment-details strong {
    font-size: 22px;
    color: #27ae60;
}

/* Order button */
.order-btn {
    margin-top: 20px;
    text-align: center;
}

.order-btn button {
    padding: 15px 30px;
    font-size: 18px;
    background-color: #27ae60;
}

.order-btn button:hover {
    background-color: #1e8449;
}

/* Change Address Button */
a button {
    background-color: #f39c12;
}

a button:hover {
    background-color: #e67e22;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        width: 95%;
        padding: 15px;
    }

    h2 {
        font-size: 22px;
    }

    p, label {
        font-size: 16px;
    }

    button {
        padding: 8px 15px;
        font-size: 14px;
    }
}

    </style>
</head>

<body>
    <div class="container">
    
        <div class="account-details">
            <h2>Account Details</h2>
            <p><strong>Name:</strong> <?php echo $customer_data['name']; ?></p>
            <p><strong>Mobile No.:</strong> <?php echo $customer_data['mobile']; ?></p>
            <p><strong>Email:</strong> <?php echo $customer_data['email']; ?></p>
            <p><strong>Address:</strong> <?php echo $customer_data['address']; ?></p>
            <a href="editInfo.php"><button>Change Address</button></a>
        </div>

       
        <div class="cart-summary">
            <h2>Cart Summary</h2>
            <table border="1">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cartItems as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td>Rs <?php echo htmlspecialchars($item['price']); ?></td>
                            <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                            <td>Rs <?php echo htmlspecialchars($item['price'] * $item['quantity']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="3">Total:</td>
                        <td>Rs <?php echo $totalAmount; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

       
        <div class="payment-details">
            <h2>Payment Details</h2>
            <form action="" method="POST">
                <p><strong>Payment Method:</strong></p>
                <input type="radio" id="cod" name="payment_method" value="Cash on Delivery (COD)" required>
                <label for="cod">Cash on Delivery (COD)</label><br>
                <input type="radio" id="upi" name="payment_method" value="UPI" required>
                <label for="upi">UPI</label><br>
                <input type="radio" id="digital_wallet" name="payment_method" value="Digital Wallet" required>
                <label for="digital_wallet">Digital Wallet</label><br>
                <p><strong>Amount Payable: Rs <?php echo $totalAmount; ?></strong></p>

                
                <div class="order-btn">
                    <button type="submit" name="order">Order Now</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>