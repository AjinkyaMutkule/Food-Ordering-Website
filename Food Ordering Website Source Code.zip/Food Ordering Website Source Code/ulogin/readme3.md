PAYMENT>PHP
<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it's not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

// Generate QR code if payment is initiated
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $price = $_POST['total_amount'] ?? $totalAmount; // Use POST amount or calculated total
    $upiID = 'mutkuleajinkya@okhdfcbank';
    $qrText = "upi://pay?pa=$upiID&am=$price&cu=INR";

    // Insert query for payment table
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $zip = $_POST['zip'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $paymentMethod = $_POST['payment_method'] ?? '';

    if (!empty($name) && !empty($email) && !empty($address) && !empty($city) && !empty($state) && !empty($zip) && !empty($phone) && !empty($paymentMethod)) {
        $query = "INSERT INTO payment (name, email, address, city, state, zip, phone, payment_method, total_amount) VALUES ('$name', '$email', '$address', '$city', '$state', '$zip', '$phone', '$paymentMethod', '$price')";
        $conn->query($query);
    } else {
        echo "Please fill in all fields.";
    }
} else {
    die("Invalid access");
    
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('background.jpg') no-repeat center center/cover;
        }

        .form-container {
            background-color: #ffffff;
            /* White background for the form */
            padding: 20px;
            border-radius: 8px;
            width: 800px;
            /* Adjusted width for two columns */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            /* Subtle shadow */
            display: flex;
        }

        .details,
        .payment {
            width: 50%;
            /* Equal width for both sections */
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .section {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            /* Bold labels */
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s;
            /* Smooth transition for border color */
        }

        input:focus,
        select:focus {
            border-color: #007BFF;
            /* Highlight border on focus */
            outline: none;
            /* Remove outline */
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            /* Smooth transition for button color */
        }

        button:hover {
            background-color: #0056b3;
            /* Darker blue on hover */
        }

        /* Payment method icons */
        .payment-methods {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .payment-methods img {
            width: 50px;
            height: auto;
            margin: 0 10px;
            /* Added margin for spacing */
        }

        /* Combined section with gray background */
        .combined-section {
            background-color: #d3d3d3;
            /* Light gray background */
            padding: 20px;
            border-radius: 8px;
            display: flex;
            width: 100%;
            /* Full width */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            /* Subtle shadow for the combined section */
            margin: auto;
        }

        /* Media query for responsive design */
        @media (max-width: 900px) {
            .form-container {
                flex-direction: column;
                /* Stack columns on smaller screens */
                width: 100%;
                /* Full width */
            }

            .details,
            .payment {
                width: 100%;
                /* Full width for both sections */
            }
        }

        .qrcode {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-container">
            <div class="details">
                <h2>Details</h2>
                <form action="" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo $totalAmount; ?>">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" required>

                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>

                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" required>

                    <label for="city">City</label>
                    <input type="text" id="city" name="city" required>

                    <label for="state">State</label>
                    <input type="text" id="state" name="state" required>

                    <label for="zip">ZIP</label>
                    <input type="text" id="zip" name="zip" required>

                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="payment">
                <h2>Payment</h2>
                <div class="payment-methods">
                    <input type="radio" id="cash" name="payment_method" value="cash on delivery">
                    <label for="cash">Cash on Delivery</label>
                    <input type="radio" id="digital" name="payment_method" value="digital wallet">
                    <label for="digital">Digital Wallet</label>
                    <input type="radio" id="upi" name="payment_method" value="upi">
                    <label for="upi">UPI</label>
                </div>
                <div id="qrcode" class="qrcode"></div>
                <script>
                    $(document).ready(function() {
                        $('input[name="payment_method"]').on('change', function() {
                            const paymentMethod = $(this).val();
                            if (paymentMethod === 'upi') {
                                const qrText = "upi://pay?pa=mutkuleajinkya@okhdfcbank&am=<?php echo $totalAmount; ?>&cu=INR";
                                $('#qrcode').empty();
                                new QRCode(document.getElementById("qrcode"), qrText);
                            } else {
                                $('#qrcode').empty();
                            }
                        });
                    });
                </script>

                
                <button type="submit"><a href="bill.php">Proceed to Checkout</a></button>
            </div>
            </form>
        </div>
    </div>
</body>

</html>



BILL>PHP

<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty!";
    exit();
}

// Fetch the cart items from the session
$cartItems = $_SESSION['cart'];

// Calculate the total amount
$totalAmount = 0;
foreach ($cartItems as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

// Fetch user details from the payment table
$userName = $userAddress = $orderDate = '';
$sql = "SELECT name, address, created_at FROM payment LIMIT 1";
if ($stmt = $conn->prepare($sql)) {
    $stmt->execute();
    $stmt->bind_result($userName, $userAddress, $orderDate);
    $stmt->fetch();
    $stmt->close();
}

// Generate a unique bill number
$billNumber = rand(2002, 3402);
?>



<?php
// Insert the order into the database using prepared statements
$sql = "INSERT INTO orders (bill_number, user_name, user_address, order_date, total_amount) VALUES (?, ?, ?, ?, ?)";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param('ssssd', $billNumber, $userName, $userAddress, $orderDate, $totalAmount);
    $stmt->execute();
    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }

        .bill-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            color: #5D5C61;
        }

        .user-details {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #5D5C61;
            border-radius: 4px;
            background-color: #f9f9f9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th,
        table td {
            border: 1px solid #5D5C61;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #5D5C61;
            color: white;
        }

        .total-amount {
            text-align: right;
            font-size: 1.2em;
            margin-top: 20px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 0.9em;
            color: #888;
        }

        .back-btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #5D5C61;
            color: white;
            text-decoration: none;
            text-align: center;
            border-radius: 4px;
        }

        .back-btn:hover {
            background-color: #4b4a4d;
        }
    </style>
</head>

<body>
    <div class="bill-container">
        <h1>Order Invoice</h1>

        <!-- User Details -->
        <div class="user-details">
            <p><strong>Bill Number:</strong> <?php echo $billNumber; ?></p>
            <p><strong>Name:</strong> <?php echo $userName; ?></p>
            <p><strong>Address:</strong> <?php echo $userAddress; ?></p>
            <p><strong>Date:</strong> <?php echo $orderDate; ?></p>
        </div>

        <!-- Order Details -->
        <h2>Order Summary</h2>
        <table>
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                        <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                        <td><?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : '0'; ?></td>
                        <td>Rs <?php echo isset($item['price'], $item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Total Amount -->
        <div class="total-amount">
            <h3>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></h3>
        </div>

        <!-- Footer Section (if required) -->
        <div class="footer">
            <p>Thank you for ordering with us!</p>
        </div>

        <!-- Back Button to return to menu -->
        <a href="menu.php" class="back-btn">Back to Menu</a>
    </div>
</body>

</html>

<?php
// Insert the order into the database
$conn->query("INSERT INTO orders (bill_number, user_name, user_address, order_date, total_amount) VALUES ('$billNumber', '$userName', '$userAddress', '$orderDate', '$totalAmount')");

$conn->close();
?>
MENU>PHP

<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to display the menu
function displayMenu($searchQuery = '') {
    global $conn;
    $sql = "SELECT * FROM menu" . ($searchQuery ? " WHERE name LIKE ?" : "");
    $stmt = $conn->prepare($sql);
    
    if ($searchQuery) {
        $searchParam = "%" . $searchQuery . "%";
        $stmt->bind_param("s", $searchParam);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<div class='card-container'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='card' data-id='" . $row['id'] . "'>";
            echo "<img src='../dataimg/" . $row["image"] . "' alt='" . $row["name"] . "' class='card-image'>";
            echo "<h2 class='card-title'>" . $row["name"] . "</h2>";
            echo "<p class='card-price'>Price: Rs: " . $row["price"] . "</p>";
            echo "<button class='add-to-cart'>Add to Cart</button>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No results found.</p>";
    }
}

// Handle search query
$searchQuery = isset($_GET['query']) ? $_GET['query'] : '';

// HTML and CSS
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order Menu</title>
    <style>
        body {
            background-image: url('../dataimg/background.jpeg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
        }

        .search-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        #search-bar {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 10px;
        }

        #search-button {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        #search-button:hover {
            background-color: #27ae60;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin: 0 auto;
            max-width: 1200px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card {
            width: 200px;
            height: 300px;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 10px;
            margin: 10px;
            display: inline-block;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
            position: relative; /* Set position to relative */
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-image {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }

        .card-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .card-price {
            font-size: 16px;
            color: #666;
        }

        .add-to-cart {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.2s ease-in-out;
        }

        .add-to-cart:hover {
            background-color: #27ae60;
        }

        .cart-button {
            position: fixed;
            top: 10px;
            right: 10px;
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.2s ease-in-out;
        }

        .cart-button:hover {
            background-color: #27ae60;
        }
    </style>
</head>
<body>

<!-- Search Bar -->
<div class="search-container">
    <input type="text" id="search-bar" placeholder="Search for food..." value="<?php echo htmlspecialchars($searchQuery); ?>">
    <button id="search-button">Search</button>
</div>

<!-- Cart Button -->
<a href="cart.php" class="cart-button">Cart<span id="cart-count"></span></a>

<!-- Menu Display -->
<?php displayMenu($searchQuery); ?>

<script>
    // Add event listener to add-to-cart buttons
    document.addEventListener("DOMContentLoaded", function() {
        const addToCartButtons = document.querySelectorAll(".add-to-cart");
        const cardContainer = document.querySelector(".card-container");

        addToCartButtons.forEach(button => {
            button.addEventListener("click", function(event) {
                event.stopPropagation(); // Prevent the click from bubbling up
                const card = this.closest('.card');
                const id = card.getAttribute("data-id");
                const xhr = new XMLHttpRequest();
                xhr.open("GET", "cart.php?action=add&id=" + id, true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Update cart count in the menu page
                            const cartCountElement = document.getElementById("cart-count");
                            cartCountElement.innerText = parseInt(cartCountElement.innerText) + 1;
                        }
                    }
                };
                xhr.send();
                // Redirect back to menu.php after adding to cart
                window.location.href = "menu.php";
            });
        });

        // Add event listener for clicks outside the card
        cardContainer.addEventListener("click", function(event) {
            const target = event.target.closest('.card');
            if (!target) {
                window.location.href = "menu.php"; // Redirect if click is outside of card
            }
        });

        // Add event listener to search button
        document.getElementById("search-button").addEventListener("click", function() {
            const query = document.getElementById("search-bar").value;
            if (query) {
                window.location.href = "?query=" + encodeURIComponent(query);
                // Reset search input after search
                document.getElementById("search-bar").value = '';
            }
        });

        // Add event listener for Enter key press in search bar
        document.getElementById("search-bar").addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                const query = this.value;
                if (query) {
                    window.location.href = "?query=" + encodeURIComponent(query);
                    // Reset search input after search
                    this.value = '';
                }
            }
        });
    });
</script>

</body>
</html>

<?php
$conn->close();
?>

CART>PHP
<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it's not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']); // Ensure $itemId is an integer

    // Use prepared statements for security
    $stmt = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
    $stmt->close();
}

// Update quantity of the item
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        // Increase or decrease quantity based on the action
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <!-- Back Button -->
    <a href="menu.php" class="back-btn">Back to Menu</a>

    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td><?php echo isset($item['id']) ? htmlspecialchars($item['id']) : 'N/A'; ?></td>
                            <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                            <td><img src="../dataimg/<?php echo isset($item['image']) ? htmlspecialchars($item['image']) : ''; ?>" alt="<?php echo isset($item['name']) ? htmlspecialchars($item['name']) : ''; ?>" width="100"></td>
                            <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=decrease&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">-</a>
                                <?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : 0; ?>
                                <a href="cart.php?action=increase&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">+</a>
                            </td>
                            <td>Rs <?php echo isset($item['price']) && isset($item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=remove&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="remove-btn">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-container">
                <strong>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></strong>
            </div>
            <div class="total-container">
                <form action="checkout.php" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                    <button type="submit" class="proceed-btn">Checkout >></button>
                </form>
            </div>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>

STATUS CHECK 1
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Status Tracker</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      width: 80%;
      max-width: 900px;
      background-color: #fff;
      border-radius: 12px;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      text-align: center;
    }

    h1 {
      color: #333;
      margin-bottom: 20px;
    }

    .tracker {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 30px;
      position: relative;
    }

    .stage {
      width: 24%;
      text-align: center;
      position: relative;
      opacity: 0.5;
      transition: opacity 0.5s ease, transform 0.5s ease;
    }

    .icon {
      border-radius: 50%;
      width: 50px;
      height: 50px;
      margin-bottom: 10px;
      display: inline-block;
      background-size: cover;
      background-position: center;
      transition: transform 0.5s ease;
    }

    .active {
      opacity: 1;
    }

    .active .icon {
      border: 3px solid green;
      transform: scale(1.1);
      animation: pulse 1s infinite alternate;
    }

    .progress-bar {
      height: 5px;
      background-color: #ddd;
      position: absolute;
      top: 25px;
      width: 100%;
      left: 50px;
      right: 50px;
      z-index: -1;
    }

    .progress {
      height: 5px;
      background-color: green;
      width: 0%;
      transition: width 1s ease;
    }

    .bike-image {
      margin-top: 30px;
      width: 100%;
      max-width: 400px;
      display: block;
      margin-left: auto;
      margin-right: auto;
    }

    @keyframes pulse {
      0% { transform: scale(1); }
      100% { transform: scale(1.2); }
    }
  </style>
</head>
<body>

<div class="container">
  <h1>Order Status Tracker</h1>

  <div class="tracker">
    <div class="stage active">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/sent.png');"></div>
      Sent
    </div>
    <div class="progress-bar">
      <div class="progress"></div>
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/checked.png');"></div>
      Confirmed
    </div>
    <div class="progress-bar">
      <div class="progress"></div>
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/scooter.png');"></div>
      On The Way
    </div>
    <div class="progress-bar">
      <div class="progress"></div>
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/delivered-box.png');"></div>
      Delivered
    </div>
  </div>

  <img class="bike-image" src="https://img.icons8.com/fluency/96/000000/delivery-scooter.png" alt="Delivery Rider">
</div>

<script>
  const stages = document.querySelectorAll('.stage');
  const progressBars = document.querySelectorAll('.progress');

  function updateProgress(stageIndex) {
    stages.forEach((stage, index) => {
      if (index <= stageIndex) {
        stage.classList.add('active');
        if (index < progressBars.length) {
          progressBars[index].style.width = '100%';
        }
      } else {
        stage.classList.remove('active');
        if (index < progressBars.length) {
          progressBars[index].style.width = '0%';
        }
      }
    });
  }

  // Simulate progress through stages with delays
  setTimeout(() => updateProgress(0), 1000); // Sent
  setTimeout(() => updateProgress(1), 3000); // Confirmed
  setTimeout(() => updateProgress(2), 6000); // On The Way
  setTimeout(() => updateProgress(3), 9000); // Delivered
</script>

</body>
</html>

STATUS CHECK 2
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Status Tracker</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }

  .container {
    width: 80%;
    max-width: 900px;
    background-color: #fff;
    border-radius: 12px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
    position: relative;
  }

  h1 {
    color: #333;
    margin-bottom: 20px;
  }

  .tracker {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 30px;
    position: relative;
    height: 100px;
  }

  /* Progress line setup */
  .line-container {
    position: relative;
    width: 100%;
    height: 5mm;
    background-color: #ddd;
    margin-top: 30px;
    border-radius: 10px;
  }

  .progress-line {
    height: 5mm;
    background-color: green;
    width: 0%;
    transition: width 1s ease;
    border-radius: 10px;
  }

  /* Delivery boy image */
  .delivery-boy {
    position: absolute;
    top: -50px; /* Positioning above the line */
    left: 0;
    transition: left 1s ease;
  }

  .delivery-boy img {
    width: 50px; /* Adjust size as needed */
    height: auto;
  }

  /* Stages */
  .stage {
    width: 24%;
    text-align: center;
    position: relative;
    opacity: 0.5;
    transition: opacity 0.5s ease, transform 0.5s ease;
  }

  .icon {
    border-radius: 50%;
    width: 20px; /* Reduced size to 5-6mm */
    height: 20px; /* Reduced size to 5-6mm */
    margin-bottom: 10px;
    display: inline-block;
    background-size: cover;
    background-position: center;
    transition: transform 0.5s ease;
  }

  .active {
    opacity: 1;
  }

  .active .icon {
    border: 2px solid green; /* Adjust border size according to the smaller icon */
    transform: scale(1.1);
    animation: pulse 1s infinite alternate;
  }

  @keyframes pulse {
    0% { transform: scale(1); }
    100% { transform: scale(1.2); }
  }
</style>

</head>
<body>

<div class="container">
  <h1>Order Status Tracker</h1>

  <!-- Delivery Boy on Progress Line -->
  <div class="line-container">
    <div class="progress-line" id="progress-line"></div>
    <div class="delivery-boy" id="delivery-boy">
      <img src="https://img.icons8.com/fluency/96/000000/delivery-scooter.png" alt="Delivery Boy on Bike">
    </div>
  </div>

  <div class="tracker">
    <div class="stage active">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/sent.png');"></div>
      Sent
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/checked.png');"></div>
      Confirmed
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/scooter.png');"></div>
      On The Way
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/delivered-box.png');"></div>
      Delivered
    </div>
  </div>
</div>

<script>
  const stages = document.querySelectorAll('.stage');
  const progressLine = document.getElementById('progress-line');
  const deliveryBoy = document.getElementById('delivery-boy');

  // Function to update the progress
  function updateProgress(stageIndex) {
    stages.forEach((stage, index) => {
      if (index <= stageIndex) {
        stage.classList.add('active');
      } else {
        stage.classList.remove('active');
      }
    });

    // Update the progress line and delivery boy position
    const progressPercentage = (stageIndex + 1) * 25; // 4 stages (25% each)
    progressLine.style.width = progressPercentage + '%';

    // Move the delivery boy along the line
    const deliveryPosition = progressPercentage + '%';
    deliveryBoy.style.left = deliveryPosition;
  }

  // Simulate progress through stages with delays
  setTimeout(() => updateProgress(0), 10000); // Sent
  setTimeout(() => updateProgress(1), 30000); // Confirmed
  setTimeout(() => updateProgress(2), 60000); // On The Way
  setTimeout(() => updateProgress(3), 90000); // Delivered
</script>

</body>
</html>

STATUS CHECK 3

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Status Tracker</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      width: 80%;
      max-width: 900px;
      background-color: #fff;
      border-radius: 12px;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      text-align: center;
      position: relative;
    }

    h1 {
      color: #333;
      margin-bottom: 20px;
    }

    .tracker {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 30px;
      position: relative;
      height: 100px;
    }

    /* Progress line setup */
    .line-container {
      position: relative;
      width: 100%;
      height: 5mm;
      background-color: #ddd;
      margin-top: 30px;
      border-radius: 10px;
    }

    .progress-line {
      height: 5mm;
      background-color: green;
      width: 0%;
      transition: width 3s ease;
      border-radius: 10px;
    }

    /* Delivery boy image */
    .delivery-boy {
      position: absolute;
      top: -50px; /* Positioning above the line */
      left: 0;
      transition: left 3s ease; /* Smooth movement of the delivery boy */
    }

    .delivery-boy img {
      width: 50px; /* Adjust size as needed */
      height: auto;
    }

    /* Stages */
    .stage {
      width: 24%;
      text-align: center;
      position: relative;
      opacity: 0.5;
      transition: opacity 0.5s ease, transform 0.5s ease;
    }

    .icon {
      border-radius: 50%;
      width: 20px; /* Adjusted to 5-6mm */
      height: 20px; /* Adjusted to 5-6mm */
      margin-bottom: 10px;
      display: inline-block;
      background-size: cover;
      background-position: center;
      transition: transform 0.5s ease;
    }

    .active {
      opacity: 1;
    }

    .active .icon {
      border: 2px solid green; /* Adjust border size according to the smaller icon */
      transform: scale(1.1);
      animation: pulse 1s infinite alternate;
    }

    @keyframes pulse {
      0% { transform: scale(1); }
      100% { transform: scale(1.2); }
    }
  </style>
</head>
<body>

<div class="container">
  <h1>Order Status Tracker</h1>

  <!-- Delivery Boy on Progress Line -->
  <div class="line-container">
    <div class="progress-line" id="progress-line"></div>
    <div class="delivery-boy" id="delivery-boy">
      <img src="https://img.icons8.com/fluency/96/000000/delivery-scooter.png" alt="Delivery Boy on Bike">
    </div>
  </div>

  <div class="tracker">
    <div class="stage active">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/sent.png');"></div>
      Sent
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/checked.png');"></div>
      Confirmed
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/scooter.png');"></div>
      On The Way
    </div>
    <div class="stage">
      <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/delivered-box.png');"></div>
      Delivered
    </div>
  </div>
</div>

<script>
  const stages = document.querySelectorAll('.stage');
  const progressLine = document.getElementById('progress-line');
  const deliveryBoy = document.getElementById('delivery-boy');

  // Function to update the progress
  function updateProgress(stageIndex) {
    stages.forEach((stage, index) => {
      if (index <= stageIndex) {
        stage.classList.add('active');
      } else {
        stage.classList.remove('active');
      }
    });

    // Update the progress line width and move the delivery boy
    const progressPercentage = (stageIndex + 1) * 25; // 4 stages (25% each)
    progressLine.style.width = progressPercentage + '%';

    // Move the delivery boy along the line smoothly
    deliveryBoy.style.left = progressPercentage + '%';
  }

  // Simulate progress through stages with delays
  setTimeout(() => updateProgress(0), 10000); // Sent
  setTimeout(() => updateProgress(1), 25000); // Confirmed
  setTimeout(() => updateProgress(2), 60000); // On The Way
  setTimeout(() => updateProgress(3), 90000); // Delivered
</script>

</body>
</html>



CHECKOUT 

<?php
// Start session
session_start();

if (isset($_SESSION["uid"])) {
  $uid = $_SESSION["uid"];
}
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "foods");

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Check if user is logged in
if (!isset($_SESSION['uid'])) {
  header('Location: login.php');
  exit;
}

// Get user data from admin/customerdb.php
$query = "SELECT * FROM user WHERE id = '" . $_SESSION['uid'] . "'";
$result = mysqli_query($conn, $query);
if ($result) {
  $customer_data = mysqli_fetch_assoc($result);
} else {
  echo "Error: " . mysqli_error($conn);
}

// Get cart data from cart.php
$cart_query = "SELECT * FROM cart WHERE id = '" . $_SESSION['uid'] . "'";
$cart_result = mysqli_query($conn, $cart_query);
if ($cart_result) {
  $cart_data = array();
  while ($row = mysqli_fetch_assoc($cart_result)) {
    $cart_data[] = $row;
  }
} else {
  echo "Error: " . mysqli_error($conn);
}

// Check if cart data is available
if (!isset($cart_data) || empty($cart_data)) {
  $cart_data = array();
}

// Calculate subtotal and total
$subtotal = 0;
foreach ($cart_data as $item) {
  $subtotal += $item['price'] * $item['quantity'];
}
$total = $subtotal + 20; // Add delivery charges
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #333;
      color: white;
      margin: 0;
      padding: 20px;
    }

    .container {
      max-width: 800px;
      margin: auto;
      padding: 20px;
      background-color: #444;
    }

    .account-details,
    .cart-summary,
    .payment-details {
      border: solid thin #555;
      padding: 20px;
      margin-bottom: 20px;
    }

    .account-details {
      margin-bottom: 10px;
    }

    .cart-summary,
    .payment-details {
      width: 48%;
    }

    .cart-summary {
      float: left;
    }

    .payment-details {
      float: right;
    }

    .clearfix::after {
      content: "";
      clear: both;
      display: table;
    }

    h2 {
      color: #8bc34a;
      text-align: center;
    }

    button {
      background-color: #8bc34a;
      color: white;
      border: none;
      padding: 10px;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="account-details">
      <h2>Account Details</h2>
      <p><strong>Name:</strong> <?php echo $customer_data['name']; ?></p>
      <p><strong>Mobile No.:</strong> <?php echo $customer_data['mobile']; ?></p>
      <p><strong>Email:</strong> <?php echo $customer_data['email']; ?></p>
      <p><strong>Address:</strong> <?php echo $customer_data['address']; ?></p>
      <button>Change Address</button>
    </div>
    <div class="clearfix">
      <div class="cart-summary">
        <h2>Cart Summary</h2>
        <?php if (!empty($cart_data)) { ?>
          <?php foreach ($cart_data as $item) { ?>
            <p><?php echo $item['product_name']; ?> x <?php echo $item['quantity']; ?> - ₹<?php echo $item['price'] * $item['quantity']; ?></p>
          <?php } ?>
          <p>Subtotal: ₹<?php echo $subtotal; ?></p>
        <?php } else { ?>
          <p>No items in cart.</p>
        <?php } ?>
      </div>
      <div class="payment-details">
        <h2>Payment Details</h2>
        <p><strong>Payment Method:</strong> Cash on Delivery (COD)</p>
        <p><strong>Payment Method:</strong> UPI</p>
        <p>Total Rewards: ₹0</p>
        <p>Total Savings: ₹0</p>
        <p>Delivery Charges: ₹20</p>
        <p><strong>Amount Payable: ₹<?php echo $total; ?></strong></p>
      </div>
    </div>
  </div>

</body>

</html>


CART 

<?php
session_start();

if (isset($_SESSION["uid"])){
    $uid = $_SESSION["uid"];
}
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it's not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']); // Ensure $itemId is an integer

    // Use prepared statements for security
    $stmt = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
    $stmt->close();
}

if(isset($_POST['submit'])){
    $sql="insert into cart values ()";
}

// Update quantity of the item
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        // Increase or decrease quantity based on the action
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <!-- Back Button -->
    <a href="menu.php" class="back-btn">Back to Menu</a>

    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td><?php echo isset($item['id']) ? htmlspecialchars($item['id']) : 'N/A'; ?></td>
                            <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                            <td><img src="../dataimg/<?php echo isset($item['image']) ? htmlspecialchars($item['image']) : ''; ?>" alt="<?php echo isset($item['name']) ? htmlspecialchars($item['name']) : ''; ?>" width="100"></td>
                            <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=decrease&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">-</a>
                                <?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : 0; ?>
                                <a href="cart.php?action=increase&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">+</a>
                            </td>
                            <td>Rs <?php echo isset($item['price']) && isset($item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=remove&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="remove-btn">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-container">
                <strong>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></strong>
            </div>
            <div class="total-container">
                <form action="checkout.php" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                    <button type="submit" class="proceed-btn" name="submit">Checkout >></button>
                </form>
            </div>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>

CART 
<?php
session_start();

if (isset($_SESSION["uid"])){
    $uid = $_SESSION["uid"];
}
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it's not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']); // Ensure $itemId is an integer

    // Use prepared statements for security
    $stmt = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
    $stmt->close();
}

if(isset($_POST['submit'])){
    $sql="insert into cart values (id,name,price,quantity,total)";
}

// Update quantity of the item
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        // Increase or decrease quantity based on the action
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <!-- Back Button -->
    <a href="menu.php" class="back-btn">Back to Menu</a>

    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td><?php echo isset($item['id']) ? htmlspecialchars($item['id']) : 'N/A'; ?></td>
                            <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                            <td><img src="../dataimg/<?php echo isset($item['image']) ? htmlspecialchars($item['image']) : ''; ?>" alt="<?php echo isset($item['name']) ? htmlspecialchars($item['name']) : ''; ?>" width="100"></td>
                            <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=decrease&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">-</a>
                                <?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : 0; ?>
                                <a href="cart.php?action=increase&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">+</a>
                            </td>
                            <td>Rs <?php echo isset($item['price']) && isset($item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=remove&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="remove-btn">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-container">
                <strong>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></strong>
            </div>
            <div class="total-container">
                <form action="checkout.php" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                    <button type="submit" class="proceed-btn" name="submit">Checkout >></button>
                </form>
            </div>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>

 body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: black;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
        }

        .account-details,
        .cart-summary,
        .payment-details {
            border: 1px solid #d3d3d3;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .order-btn {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .order-btn button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }

        .order-btn button:hover {
            background-color: #2980b9;
        }

        h2 {
            text-align: center;
            margin-top: 0;
            color: #333;
        }

        p {
            margin: 10px 0;
        }


        Check
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 900px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            text-align: center;
        }

        h1 {
            color: #333;
            font-size: 2.5em;
            margin-bottom: 20px;
        }

        .tracker {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            position: relative;
        }

        .line-container {
            position: relative;
            width: 100%;
            height: 8px;
            background-color: #ddd;
            margin-top: 30px;
            border-radius: 10px;
        }

        .progress-line {
            height: 100%;
            background-color: #28a745; /* Green */
            width: 0%;
            transition: width 3s ease;
            border-radius: 10px;
        }

        .delivery-boy {
            position: absolute;
            top: -35px; /* Positioning above the line */
            left: 0;
            transition: left 3s ease;
        }

        .delivery-boy img {
            width: 60px; /* Adjust size as needed */
            height: auto;
        }

        .stage {
            width: 23%;
            text-align: center;
            position: relative;
            opacity: 0.5;
            transition: opacity 0.5s ease, transform 0.5s ease;
        }

        .icon {
            border-radius: 50%;
            width: 30px; /* Adjusted to 30px for better visibility */
            height: 30px; /* Adjusted to 30px for better visibility */
            margin-bottom: 10px;
            display: inline-block;
            background-size: cover;
            background-position: center;
            transition: transform 0.5s ease;
        }

        .active {
            opacity: 1;
        }

        .active .icon {
            border: 2px solid #28a745; /* Green border */
            transform: scale(1.2);
            animation: pulse 1s infinite alternate;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            100% { transform: scale(1.2); }
        }

        .feedback-container {
            margin-top: 40px;
            background-color: #fff;
            border-radius: 10px;
            padding: 15px; /* Reduced padding */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .feedback-container h2 {
            margin-bottom: 10px; /* Reduced margin */
            color: #333;
        }

        .form-group {
            margin-bottom: 10px; /* Reduced margin */
        }

        .form-group label {
            display: block;
            margin-bottom: 3px; /* Reduced margin */
            font-weight: bold;
            color: #555;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 8px; /* Reduced padding */
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px; /* Reduced font size */
            transition: border-color 0.3s;
        }

        .form-group textarea {
            resize: none; /* Prevent resizing the textarea */
        }

        .submit-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 15px; /* Reduced padding */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em; /* Slightly reduced font size */
            transition: background-color 0.3s;
        }

        .submit-btn:hover {
            background-color: #218838; /* Darker green on hover */
        }

        .submit-btn:focus {
            outline: none;
            box-shadow: 0 0 5px #28a745;
        }

        .back-btn {
            background-color: #007bff; /* Blue */
            color: white;
            padding: 10px 15px; /* Reduced padding */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em; /* Slightly reduced font size */
            transition: background-color 0.3s;
            margin-top: 20px; /* Space above the button */
        }

        .back-btn:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        Order details 
        <?php
	include('../dbcon.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">


	<style type="text/css">
		.abc button{
			width: 350px;
			font-size: 20px;
		}
	</style>
</head>
<body>
	<div align="center" class="bg-dark text-light pt-4 pb-4">
		<a href="../logout.php"><button style="float: right;" class="btn btn-danger mr-3">LOGOUT</button></a>
		<a href="admindash.php"><button style="float: left;" class="btn btn-success ml-3"><< BACK</button></a>
		<h1>ORDER DETAIL</h1>	
	</div>

	<table align="center" border="1" width="90%" style="margin-top: 20px;" class="mb-5">
		<tr style="background-color: black; color: white;" align="center">
			<th width="100">User Id</th>
			<th width="150">User Name</th>
			<th width="150">Email</th>
			<th width="150">Address</th>
			<th width="180">Payment Mode</th>
			<th width="150">Item Details</th>
			
		</tr>

		<?php

			include('../dbcon.php');

			$query = "SELECT * FROM `orders` ";
			$run = mysqli_query($conn, $query);

			if (mysqli_num_rows($run) < 1) 
	        {
	        	echo "<tr><td colspan='5' align='center'>No data found</td><tr>";
	        }
			else
			{
				while ($data = mysqli_fetch_assoc($run))
				{
					?>
					<tr align="center">
						<td> <?php echo $data['orderId']; ?> </td>
						<td> <?php echo $data['itemName']; ?> </td>
						<td> <?php echo $data['price']; ?> </td>
						<td> <?php echo "x".$data['qty']; ?> </td>
						<td> <?php echo $data['total']; ?> </td>
						<td> <?php echo $data['name']; ?> </td>
						<td> <?php echo $data['address']; ?> </td>
						<td> <?php echo $data['email']; ?> </td>
					</tr>
					<?php
				}
			}
    	?>
    </table>

	<script src="bootstrap/jss/jquery.min.js"></script>
	<script src="bootstrap/jss/popper.min.js"></script>
	<script src="bootstrap/jss/bootstrap.min.js"></script>
</body>
</html>