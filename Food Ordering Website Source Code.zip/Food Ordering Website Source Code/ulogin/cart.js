function updateTotal(element, price) {
    let quantity = element.value;
    let totalPriceElement = element.parentElement.nextElementSibling;
    let totalPrice = price * quantity;
    totalPriceElement.innerText = totalPrice;

    updateTotalAmount();
}

function updateTotalAmount() {
    let totalPrices = document.querySelectorAll('.total-price');
    let totalAmount = 0;
    totalPrices.forEach(price => {
        totalAmount += parseFloat(price.innerText);
    });
    document.getElementById('total-amount').innerText = totalAmount;
}

// Initialize total amount
updateTotalAmount();