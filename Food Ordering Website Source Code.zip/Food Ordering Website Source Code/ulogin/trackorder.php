<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$orderStatus = $userName = $orderDate = $totalAmount = $userAddress = $message = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $billNumber = isset($_POST['bill_number']) ? trim($_POST['bill_number']) : '';

    // Validate input
    if (empty($billNumber)) {
        $message = "Please enter a valid bill number!";
    } else {
        // Use a prepared statement to safely query the database
        $sql = "SELECT user_name, user_address, order_date, total_amount, order_status FROM orders WHERE bill_number = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param('s', $billNumber);
            $stmt->execute();
            $stmt->bind_result($userName, $userAddress, $orderDate, $totalAmount, $orderStatus);

            if ($stmt->fetch()) {
                // Order details fetched successfully
                $stmt->close();
            } else {
                // No order found for the given bill number
                $message = "No order found with the given bill number.";
                $stmt->close();
            }
        } else {
            $message = "Error preparing statement: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .tracking-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .tracking-form {
            text-align: center;
            margin-bottom: 20px;
        }

        .tracking-form input[type="text"] {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 10px;
        }

        .tracking-form input[type="submit"] {
            padding: 10px 20px;
            background-color: #5D5C61;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .tracking-form input[type="submit"]:hover {
            background-color: #4b4a4d;
        }

        .order-details {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #f9f9f9;
        }

        .order-details p {
            margin: 10px 0;
        }

        .message {
            color: red;
            text-align: center;
        }

        /* Progress Bar Styles */
        .progress-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
        }

        .progress-step {
            text-align: center;
            width: 100%;
            position: relative;
        }

        .progress-step::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translateX(-50%);
            height: 5px;
            width: 100%;
            background-color: #ddd;
            z-index: -1;
        }

        .progress-step span {
            display: block;
            background-color: #ddd;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin: 0 auto;
        }

        .progress-step.active span {
            background-color: #5D5C61;
        }

        .progress-step:first-child::before {
            display: none;
        }

        .progress-label {
            margin-top: 10px;
            font-size: 14px;
            color: #333;
        }

        .progress-step.active .progress-label {
            color: #5D5C61;
            font-weight: bold;
        }

    </style>
</head>
<body>
    <div class="tracking-container">
        <h1>Track Your Order</h1>
        
        <form action="track_order.php" method="post" class="tracking-form">
            <input type="text" name="bill_number" placeholder="Enter Bill Number" required>
            <input type="submit" value="Track Order">
        </form>

        <?php if (!empty($message)): ?>
            <div class="message">
                <p><?php echo htmlspecialchars($message); ?></p>
            </div>
        <?php endif; ?>

        <?php if (!empty($orderStatus)): ?>
            <div class="order-details">
                <p><strong>Name:</strong> <?php echo htmlspecialchars($userName); ?></p>
                <p><strong>Address:</strong> <?php echo htmlspecialchars($userAddress); ?></p>
                <p><strong>Order Date:</strong> <?php echo htmlspecialchars($orderDate); ?></p>
                <p><strong>Total Amount:</strong> Rs <?php echo htmlspecialchars($totalAmount); ?></p>
            </div>

            <!-- Order Progress Bar -->
            <div class="progress-container">
                <div class="progress-step <?php echo $orderStatus == 'Order Placed' || $orderStatus == 'Cooking Started' || $orderStatus == 'Packed' || $orderStatus == 'Dispatched' || $orderStatus == 'Delivered' ? 'active' : ''; ?>">
                    <span></span>
                    <div class="progress-label">Order Placed</div>
                </div>

                <div class="progress-step <?php echo $orderStatus == 'Cooking Started' || $orderStatus == 'Packed' || $orderStatus == 'Dispatched' || $orderStatus == 'Delivered' ? 'active' : ''; ?>">
                    <span></span>
                    <div class="progress-label">Cooking Started</div>
                </div>

                <div class="progress-step <?php echo $orderStatus == 'Packed' || $orderStatus == 'Dispatched' || $orderStatus == 'Delivered' ? 'active' : ''; ?>">
                    <span></span>
                    <div class="progress-label">Packed</div>
                </div>

                <div class="progress-step <?php echo $orderStatus == 'Dispatched' || $orderStatus == 'Delivered' ? 'active' : ''; ?>">
                    <span></span>
                    <div class="progress-label">Dispatched</div>
                </div>

                <div class="progress-step <?php echo $orderStatus == 'Delivered' ? 'active' : ''; ?>">
                    <span></span>
                    <div class="progress-label">Delivered</div>
                </div>
            </div>

        <?php endif; ?>
    </div>
</body>
</html>
