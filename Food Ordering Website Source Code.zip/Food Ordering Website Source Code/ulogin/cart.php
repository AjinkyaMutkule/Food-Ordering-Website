<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION["uid"])) {
    $uid = $_SESSION["uid"];
} else {
    die("User is not logged in.");
}

$conn = new mysqli("localhost", "root", "", "foods");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);  // Ensure $itemId is an integer

    // Use prepared statements to fetch the item details
    $stmt = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    if ($stmt === false) {
        die("SQL error: " . $conn->error);  // Handle SQL error
    }

    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
    $stmt->close();
}

// Store cart details in the `cart1` table when checkout is clicked
if (isset($_POST['submit'])) {
    if (!empty($_SESSION['cart'])) {
        // Initialize the variable to hold the formatted cart items
        $cartItemsFormatted = '';

        foreach ($_SESSION['cart'] as $item) {
            if (isset($item['name'], $item['quantity'], $item['price'])) {
                // Format item data as "item_name->quantity->price"
                $cartItemsFormatted .= $item['name'] . '->' . $item['quantity'] . '->' . $item['price'] . ', ';
            }
        }

        // Remove the last comma and space
        $cartItemsFormatted = rtrim($cartItemsFormatted, ', ');

        // Prepare to insert into the cart1 table
        $userId = $_SESSION['uid'];
        $total = array_sum(array_map(function($item) {
            return $item['price'] * $item['quantity'];
        }, $_SESSION['cart']));

        // Insert into the cart1 table
        $stmt = $conn->prepare("INSERT INTO cart1 (user_id, item_details, total) VALUES (?, ?, ?)");
        if ($stmt === false) {
            die("SQL error: " . $conn->error);  // Handle SQL error
        }

        // Ensure correct types are used
        $stmt->bind_param("isd", $userId, $cartItemsFormatted, $total);
        $stmt->execute();
        $stmt->close();

        // Do not clear the cart after checkout
        // $_SESSION['cart'] = array();  // This line is commented out

        // Redirect to checkout.php after inserting data
        header("Location: Checkout.php");
        exit();
    } else {
        echo "<script>alert('Your cart is empty. Please add items before checking out.');</script>";
    }
}

// Update item quantity in the cart
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove the item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>

    <a href="menu.php" class="back-btn">Back to Menu</a>

    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['id']); ?></td>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td><img src="../dataimg/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" width="100"></td>
                            <td>Rs <?php echo htmlspecialchars($item['price']); ?></td>
                            <td>
                                <a href="cart.php?action=decrease&id=<?php echo urlencode($item['id']); ?>" class="quantity-btn">-</a>
                                <?php echo htmlspecialchars($item['quantity']); ?>
                                <a href="cart.php?action=increase&id=<?php echo urlencode($item['id']); ?>" class="quantity-btn">+</a>
                            </td>
                            <td>Rs <?php echo htmlspecialchars($item['price'] * $item['quantity']); ?></td>
                            <td>
                                <a href="cart.php?action=remove&id=<?php echo urlencode($item['id']); ?>" class="remove-btn">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-container">
                <strong>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></strong>
            </div>
            <div class="total-container">
                <form action="cart.php" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                    <button type="submit" class="proceed-btn" name="submit">Checkout</button>
                </form>
            </div>
        <?php else: ?>
            <p>Your cart is empty. Please add items before checking out.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
