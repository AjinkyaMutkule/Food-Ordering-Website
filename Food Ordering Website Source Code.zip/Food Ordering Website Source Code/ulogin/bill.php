<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
   
    header('Location: order_confirmation.php'); 
    exit();
}

$cartItems = $_SESSION['cart'];

$totalAmount = 0;
foreach ($cartItems as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

$userName = $userAddress = '';
$userId = $_SESSION['uid']; 

$sql = "SELECT name, address FROM user WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $userId); 
    $stmt->execute();
    $stmt->bind_result($userName, $userAddress);
    $stmt->fetch();
    $stmt->close();
}
date_default_timezone_set('Asia/Kolkata');


$orderDate = date('Y-m-d H:i:s'); 

$billNumber = rand(2002, 3402);


$sql = "INSERT INTO bill (bill_number, user_name, user_address, order_date, total_amount) VALUES (?, ?, ?, ?, ?)";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param('ssssd', $billNumber, $userName, $userAddress, $orderDate, $totalAmount);
    $stmt->execute();
    $stmt->close();
}







$userId = $_SESSION['uid']; 
$userName = $userAddress = $userEmail = '';
$sql = "SELECT id, name, email, address FROM user WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $userId); 
    $stmt->execute();
    $stmt->bind_result($userId, $userName, $userEmail, $userAddress);
    $stmt->fetch();
    $stmt->close();
}


$paymentMode = $orderDetails = '';
$sql = "SELECT payment_method, order_details FROM payments WHERE user_id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $userId); 
    $stmt->execute();
    $stmt->bind_result($paymentMode, $orderDetails);
    $stmt->fetch();
    $stmt->close();
}
$orderDetails = '';

    foreach ($_SESSION['cart'] as $item) {
        if (isset($item['name'], $item['quantity'], $item['price'])) {
            // Format item data as "item_name->quantity->price"
            $orderDetails .= $item['name'] . '->' . $item['quantity'] . '->' . $item['price'] . ', ';
        }
    }

$sql = "INSERT INTO orders (userId,user_name,email,address,payment_mode,items_details) VALUES (?, ?, ?, ?, ?, ?)";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param('ssssss', $userId, $userName, $userEmail, $userAddress, $paymentMode, $orderDetails);
    $stmt->execute();
    $stmt->close();
}
unset($_SESSION['cart']);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill</title>

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }

        .bill-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        h1 {
            text-align: center;
            color: #2C3E50;
            font-size: 24px;
        }

        .hotel-name {
            text-align: center;
            font-size: 28px;
            color: #7f8c8d; /* Changed to gray */
            margin-bottom: 10px;
        }

        .user-details {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #7f8c8d; /* Changed to gray */
            border-radius: 4px;
            background-color: #ecf0f1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th,
        table td {
            border: 1px solid #7f8c8d; 
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #7f8c8d; 
            color: white;
        }

        .total-amount {
            text-align: right;
            font-size: 1.5em;
            margin-top: 20px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 0.9em;
            color: #888;
        }

        .print-btn,
        .check-status-btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #7f8c8d; 
            color: white;
            text-decoration: none;
            text-align: center;
            border-radius: 4px;
            font-size: 1em;
        }

        .print-btn:hover,
        .check-status-btn:hover {
            background-color: #95a5a6; 
        }

        @media print {
            .print-btn {
                display: none;
        }
    </style>

    <script>
        function printBill() {
            window.print();
        }
    </script>
</head>

<body>
    <div class="bill-container">
        <h1 class="hotel-name">Food Hunt</h1>
        <h2>Bill</h2>

        <!-- User Details -->
        <div class="user-details">
            <p><strong>Bill Number:</strong> <?php echo htmlspecialchars($billNumber); ?></p>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($userName); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($userAddress); ?></p>
            <p><strong>Date:</strong> <?php echo htmlspecialchars($orderDate); ?></p>
        </div>

        <!-- Order Details -->
        <h2>Order Summary</h2>
        <table>
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                        <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                        <td><?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : '0'; ?></td>
                        <td>Rs <?php echo isset($item['price'], $item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Total Amount -->
        <div class="total-amount">
            <h3>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></h3>
        </div>

        <!-- Footer Section -->
        <div class="footer">
            <p>Thank you for ordering with us!</p>
        </div>

        <!-- Print Button -->
        <button onclick="printBill()" class="print-btn">Print Bill</button>

        <!-- Check Order Status Button -->
        <a href="checkstatus.php" class="check-status-btn">Check Order Status</a>
    </div>
</body>

</html>
