<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['uid'])) {
    header('Location: login.php');
    exit;
}

// Check if the order was successfully placed
if (!isset($_SESSION['cart']) || !empty($_SESSION['cart'])) {
    header('Location: Checkout.php'); // Redirect back to Checkout if the cart is not empty
    exit;
}

// Get user data from user table
$conn = mysqli_connect("localhost", "root", "", "foods");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT * FROM user WHERE id = '" . $_SESSION['uid'] . "'";
$result = mysqli_query($conn, $query);
$customer_data = mysqli_fetch_assoc($result);

// Clear cart session

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to external CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: black;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        p {
            font-size: 18px;
            text-align: center;
            margin: 10px 0;
        }

        .account-details {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #d3d3d3;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #4CAF50;
            color: white;
            font-size: 18px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Order Confirmed!</h1>
        <p>Thank you for your order, <strong><?php echo htmlspecialchars($customer_data['name']); ?></strong>!</p>
        <p>Your order has been successfully placed and will be processed shortly.</p>

        <div class="account-details">
            <h3>Your Details:</h3>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($customer_data['name']); ?></p>
            <p><strong>Mobile No.:</strong> <?php echo htmlspecialchars($customer_data['mobile']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($customer_data['email']); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($customer_data['address']); ?></p>
        </div>

        <a href="bill.php" class="btn">Get Bill</a>
    </div>
</body>

</html>
