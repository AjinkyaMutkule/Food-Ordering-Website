```php
<?php
session_start();

if (isset($_SESSION["uid"])){
    $uid = $_SESSION["uid"];
}
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to display the menu
function displayMenu($searchQuery = '') {
    global $conn;
    $sql = "SELECT * FROM menu" . ($searchQuery ? " WHERE name LIKE ?" : "");
    $stmt = $conn->prepare($sql);
    
    if ($searchQuery) {
        $searchParam = "%" . $searchQuery . "%";
        $stmt->bind_param("s", $searchParam);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<div class='card-container'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='card' data-id='" . $row['id'] . "'>";
            echo "<img src='../dataimg/" . $row["image"] . "' alt='" . $row["name"] . "' class='card-image'>";
            echo "<h2 class='card-title'>" . $row["name"] . "</h2>";
            echo "<p class='card-price'>Price: Rs: " . $row["price"] . "</p>";
            echo "<button class='add-to-cart'>Add to Cart</button>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No results found.</p>";
    }
}

// Handle search query
$searchQuery = isset($_GET['query']) ? $_GET['query'] : '';

// HTML and CSS
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order Menu</title>
    <style>
        body {
            background-image: url('../dataimg/background.jpeg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
        }

        .search-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        #search-bar {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 10px;
        }

        #search-button {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        #search-button:hover {
            background-color: #27ae60;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin: 0 auto;
            max-width: 1200px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card {
            width: 200px;
            height: 300px;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 10px;
            margin: 10px;
            display: inline-block;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
            position: relative; /* Set position to relative */
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-image {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }

        .card-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .card-price {
            font-size: 16px;
            color: #666;
        }

        .add-to-cart {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.2s ease-in-out;
        }

        .add-to-cart:hover {
            background-color: #27ae60;
        }

        .cart-button {
            position: fixed;
            top: 10px;
            right: 10px;
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.2s ease-in-out;
        }

        .cart-button:hover {
            background-color: #27ae60;
        }
        /* Log-Reg Home Link */
.log-reg {
    text-align: left; /* Align the link to the left */
    margin-top: 10px;
    margin-left: 10px; /* Adjust the left margin */
}

.log-reg a {
    font-size: 14px; /* Reduced font size */
    color:  #fff; /* Green color */
    text-decoration: none;
    background-color:#2ecc71;
    padding: 8px 16px; /* Adjusted padding for smaller size */
    border-radius: 5px;
    border: 2px solid #2ecc71; /* Green border */
    transition: all 0.3s ease-in-out;
}

.log-reg a:hover {
    background-color: #2ecc71; /* Green background on hover */
    color: green;
    border-color: #27ae60; /* Darker green border on hover */
}

    </style>
</head>
<body>
<div class="log-reg">
            <a href="../index.php">Home</a>
        </div>
<!-- Search Bar -->
<div class="search-container">
    <input type="text" id="search-bar" placeholder="Search for food..." value="<?php echo htmlspecialchars($searchQuery); ?>">
    <button id="search-button">Search</button>
</div>

<!-- Cart Button -->
<a href="cart.php" class="cart-button">Cart<span id="cart-count"></span></a>

<!-- Menu Display -->
<?php displayMenu($searchQuery); ?>

<script>
    // Add event listener to add-to-cart buttons
    document.addEventListener("DOMContentLoaded", function() {
        const addToCartButtons = document.querySelectorAll(".add-to-cart");
        const cardContainer = document.querySelector(".card-container");

        addToCartButtons.forEach(button => {
            button.addEventListener("click", function(event) {
                event.stopPropagation(); // Prevent the click from bubbling up
                const card = this.closest('.card');
                const id = card.getAttribute("data-id");
                const xhr = new XMLHttpRequest();
                xhr.open("GET", "cart.php?action=add&id=" + id, true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Update cart count in the menu page
                            const cartCountElement = document.getElementById("cart-count");
                            if(cartCountElement.innerText === ''){
                                cartCountElement.innerText = 1;
                            }else{
                                cartCountElement.innerText = parseInt(cartCountElement.innerText) + 1;
                            }
                        }
                    }
                };
                xhr.send();
            });
        });

        // Add event listener for clicks outside the card
        cardContainer.addEventListener("click", function(event) {
            const target = event.target.closest('.card');
            if (!target) {
                window.location.href = "menu.php"; // Redirect if click is outside of card
            }
        });

        // Add event listener to search button
        document.getElementById("search-button").addEventListener("click", function() {
            const query = document.getElementById("search-bar").value;
            if (query) {
                window.location.href = "?query=" + encodeURIComponent(query);
                // Reset search input after search
                document.getElementById("search-bar").value = '';
            }
        });

        // Add event listener for Enter key press in search bar
        document.getElementById("search-bar").addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                const query = this.value;
                if (query) {
                    window.location.href = "?query=" + encodeURIComponent(query);
                    // Reset search input after search
                    this.value = '';
                }
            }
        });
    });
</script>

</body>
</html>

<?php
$conn->close();
?>
```