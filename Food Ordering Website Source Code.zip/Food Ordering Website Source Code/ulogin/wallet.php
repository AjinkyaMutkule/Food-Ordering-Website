<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Dummy user data (replace with real user data retrieval logic)
$userName = "John Doe";
$walletBalance = 500; // Example balance

// Handle top-up request
$qrText = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['topup_amount'])) {
    $topupAmount = $_POST['topup_amount'];
    $upiID = 'mutkuleajinkya@okhdfcbank';
    $qrText = "upi://pay?pa=$upiID&am=$topupAmount&cu=INR";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wallet Top-Up</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: grey;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .card {
            background-color: grey;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        .balance {
            font-size: 18px;
            margin-bottom: 20px;
            color: #666;
        }

        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        .qrcode {
            margin-top: 20px;
            display: none;
        }

        .qrcode.show {
            display: block;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Wallet Top-Up</h2>
    <div class="balance">Available Balance: ₹<?php echo $walletBalance; ?></div>
    
    <form method="POST" id="topupForm">
        <input type="number" name="topup_amount" placeholder="Enter amount" required min="1" step="0.01">
        <button type="submit">Top-Up</button>
    </form>

    <div id="qrcode" class="qrcode"></div>
</div>

<script>
    $(document).ready(function() {
        const qrText = "<?php echo isset($qrText) ? $qrText : ''; ?>";
        if (qrText) {
            $('#qrcode').addClass('show');
            $('#qrcode').empty();
            new QRCode(document.getElementById("qrcode"), qrText);
        }
    });
</script>

</body>
</html>
