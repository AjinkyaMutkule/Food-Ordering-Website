
<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create a page for menu of a food order site
function displayMenu() {
    global $conn;
    $sql = "SELECT * FROM menu";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div class='card-container'>";
        while($row = $result->fetch_assoc()) {
            echo "<div class='card'>";
            echo "<img src='../dataimg/" . $row["image"] . "' alt='" . $row["name"] . "' class='card-image'>";
            echo "<h2 class='card-title'>" . $row["name"]. "</h2>";
            echo "<p class='card-price'>Price: Rs :" . $row["price"]. "</p>";
            echo "<button class='order-now'>Order Now</button>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "0 results";
    }
}

displayMenu();

$conn->close();
?>
<style>
    body {
        background-image: url('../dataimg/background.jpeg');
        background-size: cover;
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
    
    }

    .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin: 0 auto;
        max-width: 1200px;
        background-color: rgba(255, 255, 255, 0.8);
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .card {
        width: 200px;
        height: 300px;
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 10px;
        margin: 10px;
        display: inline-block;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease-in-out;
    }

    .card:hover {
        transform: scale(1.05);
    }

    .card-image {
        width: 100%;
        height: 150px;
        object-fit: cover;
        border-radius: 10px 10px 0 0;
    }

    .card-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .card-price {
        font-size: 16px;
        color: #666;
    }

    .order-now {
        background-color: #2ecc71;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.2s ease-in-out;
    }

    .order-now:hover {
        background-color: #27ae60;
    }
</style>
if we search the menu and click on the search button then the this menu will be show and search button is under the search menu box and rewrite the wholecode
<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "foods");

// Fetch items from database
$sql = " SELECT id , name , price , type FROM items ";
$result = $conn->query($sql);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>
        table { width: 50%; margin: auto; border-collapse: collapse; }
        th, td { padding: 10px; text-align: center; border: 1px solid #ddd; }
        th { background-color: #f4f4f4; }
    </style>
</head>
<body>
    <h2 style="text-align: center;">Shopping Cart</h2>
    <table>
        <tr>
            <th>Item ID</th>
            <th>Item Name</th>
            <th>Item Type</th>
            <th>Item Price</th>
            <th>Quantity</th>
            <th>Total Price</th>
        </tr>
        <?php
          try {
              $dsn = "mysql:host=localhost;dbname=foods;charset=utf8"; 
              $username = "root"; 
              $password = ""; 

              
              $pdo = new PDO($dsn, $username, $password);
              $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 

              
              $sql = "SELECT id, name, price ,type FROM menu";
              $stmt = $pdo->query($sql);

            
              $menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

            
              foreach ($menuItems as $item) {
                  echo htmlspecialchars($item['name']) . " - $" . number_format($item['price'], 2) . "<br>";
              }

          } catch (PDOException $e) {
              echo "Error: " . $e->getMessage();
            }
        ?>
    </table>
    <h3 style="text-align: center;">Total Amount: <span id="total-amount">0</span></h3>

    <script>
        function updateTotal(element, price) {
            let quantity = element.value;
            let totalPriceElement = element.parentElement.nextElementSibling;
            let totalPrice = price * quantity;
            totalPriceElement.innerText = totalPrice;

            updateTotalAmount();
        }

        function updateTotalAmount() {
            let totalPrices = document.querySelectorAll('.total-price');
            let totalAmount = 0;
            totalPrices.forEach(price => {
                totalAmount += parseFloat(price.innerText);
            });
            document.getElementById('total-amount').innerText = totalAmount;
        }

        // Initialize total amount
        updateTotalAmount();
    </script>
</body>
</html>

<?php
$conn->close();
?>

<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize cart session
session_start();

if (isset($_GET['action']) && $_GET['action'] == 'add') {
    $id = $_GET['id'];
    $sql = "SELECT * FROM menu WHERE id = '$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Check if item is already in cart
        $cart = $_SESSION['cart'] ?? array();
        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = array(
                'name' => $row['name'],
                'price' => $row['price'],
                'quantity' => 1
            );
        }
        $_SESSION['cart'] = $cart;
        echo json_encode(array('success' => true, 'cartCount' => count($cart)));
    } else {
        echo json_encode(array('success' => false));
    }
    exit;
}

// Display cart items
if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    echo "<h2>Cart Items</h2>";
    echo "<table>";
    echo "<tr><th>Name</th><th>Price</th><th>Quantity</th><th>Total</th></tr>";
    $totalAmount = 0;
    foreach ($_SESSION['cart'] as $id => $item) {
        echo "<tr>";
        echo "<td>" . $item['name'] . "</td>";
        echo "<td>Rs " . $item['price'] . "</td>";
        echo "<td><input type='number' value='" . $item['quantity'] . "' onchange='updateTotal(this, " . $item['price'] . ", " . $id . ")'></td>";
        echo "<td class='total-price' id='total-" . $id . "'>Rs " . ($item['price'] * $item['quantity']) . "</td>";
        echo "</tr>";
        $totalAmount += $item['price'] * $item['quantity'];
    }
    echo "</table>";
    echo "<p id='total-amount'>Total Amount: Rs <span>" . $totalAmount . "</span></p>";
} else {
    echo "<h2>Cart is empty</h2>";
}

$conn->close();
?>

<script>
    function updateTotal(element, price, id) {
        let quantity = element.value;
        let totalPriceElement = document.getElementById('total-' + id);
        let totalPrice = price * quantity;
        totalPriceElement.innerText = 'Rs ' + totalPrice;

        updateTotalAmount();
    }

    function updateTotalAmount() {
        let totalPrices = document.querySelectorAll('.total-price');
        let totalAmount = 0;
        totalPrices.forEach(price => {
            totalAmount += parseFloat(price.innerText.replace('Rs ', ''));
        });
        document.getElementById('total-amount').innerText = 'Total Amount: Rs ' + totalAmount;
    }
</script>





Cart File



<head>
    <style>
        table {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 50%; /* You can adjust the width as needed */
        }

        #total-amount {
            position: absolute;
            bottom: 0;
            left: 0;
            transform: translateY(100%);
            width: 100%; /* You can adjust the width as needed */
            text-align: left;
            font-weight: bold;
            background-color: #f0f0f0; /* You can adjust the background color as needed */
            padding: 10px;
        }
    </style>
</head>

<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize cart session
session_start();

if (isset($_GET['action']) && $_GET['action'] == 'add') {
    $id = $_GET['id'];
    $sql = "SELECT * FROM menu WHERE id = '$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Check if item is already in cart
        $cart = $_SESSION['cart'] ?? array();
        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = array(
                'name' => $row['name'],
                'price' => $row['price'],
                'quantity' => 1
            );
        }
        $_SESSION['cart'] = $cart;
        echo json_encode(array('success' => true, 'cartCount' => count($cart)));
    } else {
        echo json_encode(array('success' => false));
    }
    exit;
}
$sql = "SELECT * FROM menu";
$result = $conn->query($sql);

// Display cart items
if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    ?>
    <div class="cart-container" style="text-align: center;">
        <h2>Cart Items</h2>
        <table style="margin: 0 auto; border-collapse: collapse;">
            <tr>
                <th style="border: 1px solid black; padding: 10px;">Name</th>
                <th style="border: 1px solid black; padding: 10px;">Price</th>
                <th style="border: 1px solid black; padding: 10px;">Quantity</th>
                <th style="border: 1px solid black; padding: 10px;">Total</th>
            </tr>
            <?php
            $totalAmount = 0;
            foreach ($_SESSION['cart'] as $id => $item) {
                ?>
                <tr>
                    <td style="border: 1px solid black; padding: 10px; font-weight: bold;"><?php echo $item['name']; ?></td>
                    <td style="border: 1px solid black; padding: 10px;">Rs <?php echo $item['price']; ?></td>
                    <td style="border: 1px solid black; padding: 10px;"><input type='number' value='<?php echo $item['quantity']; ?>' onchange='updateTotal(this, <?php echo $item['price']; ?>, <?php echo $id; ?>)'></td>
                    <td class='total-price' id='total-<?php echo $id; ?>' style="border: 1px solid black; padding: 10px;">Rs <?php echo ($item['price'] * $item['quantity']); ?></td>
                </tr>
                <?php
                $totalAmount += $item['price'] * $item['quantity'];
            }
            ?>
        </table>
        <p id='total-amount' style="font-weight: bold;">Total Amount: Rs <span id="total-amount-value"><?php echo $totalAmount; ?></span></p>
    </div>
    <?php
} else {
    ?>
    <h2>Cart is empty</h2>
    <?php
}

$conn->close();
?>

<script>
    function updateTotal(element, price, id) {
        let quantity = element.value;
        let totalPriceElement = document.getElementById('total-' + id);
        let totalPrice = price * quantity;
        totalPriceElement.innerText = 'Rs ' + totalPrice;

        updateTotalAmount();
    }

    function updateTotalAmount() {
        let totalPrices = document.querySelectorAll('.total-price');
        let totalAmount = 0;
        totalPrices.forEach(price => {
            totalAmount += parseFloat(price.innerText.replace('Rs ', ''));
        });
        document.getElementById('total-amount-value').innerText = totalAmount;
    }
</script>

database 


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";




CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(11) NOT NULL,
  `password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');


CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `item_no` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `detail` varchar(500) NOT NULL,
  `price` varchar(50) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `item_no`, `name`, `type`, `detail`, `price`, `image`) VALUES
(1, 4, 'Naan', 'Veg', 'Naan is a leavened, oven-baked flatbread.', '12', 'naan.jpg'),
(2, 5, 'Paneer Bhurji', 'Veg', 'Scrambled Indian cottage cheese with onion, tomatoes and spices.', '50', 'paneer-bhurji.jpg'),
(3, 6, 'Pulav', 'Veg', 'Vegetable Pulao (Veg Pulav) is a spicy rice dish prepared by cooking rice with various vegetables and spices.', '60', 'pulav.jpg'),
(4, 7, 'Biryani', 'Non Veg', 'Chicken Biryani is a delicious savory rice dish loaded with spicy marinated chicken, caramelized onions, and flavorful saffron rice.', '100', 'biryani.jpg'),
(5, 8, 'Fish', 'Non Veg', 'Fish fry is a meal containing battered or breaded fried fish.', '100', 'fish.jpg'),
(6, 9, 'Butter Chicken', 'Non Veg', 'Butter chicken or makhan murg is a dish, originating in the Indian subcontinent, of chicken in a mildly spiced tomato sauce.', '99', 'Butter-Chicken.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `Id` int(11) NOT NULL,
  `orderId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `itemName` varchar(50) NOT NULL,
  `price` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`Id`, `orderId`, `userId`, `itemName`, `price`, `qty`, `total`, `name`, `address`, `email`) VALUES
(77, 13, 13, 'Paneer Bhurji', '50', 1, '217', 'Jethalal Gada', 'Flat No. 100, B wing Gokuldhan Soceity, Powder Gully, Goregoan Mumbai, 400005', 'jethiya@gmail.com');



CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `cpassword` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



INSERT INTO `user` (`id`, `name`, `mobile`, `address`, `email`, `password`, `cpassword`) VALUES
(1, 'Jethalal Gada', '987456321', 'Flat No. 100, B wing Gokuldhan Soceity, Powder Gully, Goregoan Mumbai, 400005', 'jethiya1@gmail.com', 'jethiya@123', 'jethiya@123');


ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_no` (`item_no`);


ALTER TABLE `order`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;


ALTER TABLE `order`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

menu.php

<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create a page for menu of a food order site
function displayMenu() {
    global $conn;
    $sql = "SELECT * FROM menu";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div class='card-container'>";
        while($row = $result->fetch_assoc()) {
            echo "<div class='card'>";
            echo "<img src='../dataimg/" . $row["image"] . "' alt='" . $row["name"] . "' class='card-image'>";
            echo "<h2 class='card-title'>" . $row["name"]. "</h2>";
            echo "<p class='card-price'>Price: Rs :" . $row["price"]. "</p>";
            echo "<button class='add-to-cart' data-id='" . $row['id'] . "'>Add to Cart</button>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "0 results";
    }
}

displayMenu();

$conn->close();
?>

<style>
    body {
        background-image: url('../dataimg/background.jpeg');
        background-size: cover;
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
    }

    .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin: 0 auto;
        max-width: 1200px;
        background-color: rgba(255, 255, 255, 0.8);
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .card {
        width: 200px;
        height: 300px;
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 10px;
        margin: 10px;
        display: inline-block;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease-in-out;
    }

    .card:hover {
        transform: scale(1.05);
    }

    .card-image {
        width: 100%;
        height: 150px;
        object-fit: cover;
        border-radius: 10px 10px 0 0;
    }

    .card-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .card-price {
        font-size: 16px;
        color: #666;
    }

    .add-to-cart {
        background-color: #2ecc71;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.2s ease-in-out;
    }

    .add-to-cart:hover {
        background-color: #27ae60;
    }

    a{
        text-decoration: none;
        color: inherit;
    }

    .cart-button {
        position: fixed;
        top: 10px;
        right: 10px;
        background-color: #2ecc71;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.2s ease-in-out;
    }

    .cart-button:hover {
        background-color: #27ae60;
    }
</style>

<script>
    // Add event listener to add-to-cart buttons
    document.addEventListener("DOMContentLoaded", function() {
        const addToCartButtons = document.querySelectorAll(".add-to-cart");
        addToCartButtons.forEach(button => {
            button.addEventListener("click", function() {
                const id = this.getAttribute("data-id");
                const xhr = new XMLHttpRequest();
                xhr.open("GET", "cart.php?action=add&id=" + id, true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Update cart count in the menu page
                            const cartCountElement = document.getElementById("cart-count");
                            cartCountElement.innerText = parseInt(cartCountElement.innerText) + 1;
                        }
                    }
                };
                xhr.send();
            });
        });
    });

    // Add event listener to cart button to update cart count
    document.getElementById("cart-button").addEventListener("click", function() {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "cart.php?action=getCartCount", true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                const cartCountElement = document.getElementById("cart-count");
                cartCountElement.innerText = response.cartCount;
            }
        };
        xhr.send();
    });
</script>

<a href="cart.php" class="cart-button">Cart (<span id="cart-count">0</span>)</a>

<?php
// cart.php
if (isset($_GET['action'])) {
    if ($_GET['action'] == 'add') {
        $id = $_GET['id'];
        // Add item to cart
        // For demonstration purposes, we'll just increment the cart count
        $cartCount = 1;
        echo json_encode(array('success' => true, 'cartCount' => $cartCount));
    } elseif ($_GET['action'] == 'getCartCount') {
        // Get cart count
        // For demonstration purposes, we'll just return a static count
        $cartCount = 0;
        echo json_encode(array('cartCount' => $cartCount));
    }
}
?>


cart.php
<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it's not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = $_GET['id'];

    // Get item details from the database
    $sql = "SELECT * FROM menu WHERE id = $itemId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
}

// Update quantity of the item
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = $_GET['id'];

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        // Increase or decrease quantity based on the action
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = $_GET['id'];
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .cart-container {
            margin: 50px;
        }
        .total-container {
            text-align: right;
            margin: 20px;
            font-size: 20px;
        }
        .proceed-btn {
            background-color: #2ecc71;
            color: white;
            padding: 10px 20px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .proceed-btn:hover {
            background-color: #27ae60;
        }
        .remove-btn, .quantity-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .quantity-btn {
            background-color: #3498db;
        }
        .quantity-btn:hover, .remove-btn:hover {
            background-color: #2980b9;
        }
        .remove-btn:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

<div class="cart-container">
    <h1>Your Cart</h1>
    <?php if (!empty($_SESSION['cart'])): ?>
        <table>
            <thead>
                <tr>
                    <th>Item ID</th>
                    <th>Item Name</th>
                    <th>Image</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['cart'] as $item): ?>
                    <tr>
                        <td><?php echo isset($item['id']) ? $item['id'] : 'N/A'; ?></td>
                        <td><?php echo isset($item['name']) ? $item['name'] : 'N/A'; ?></td>
                        <td><img src="../dataimg/<?php echo isset($item['image']) ? $item['image'] : ''; ?>" alt="<?php echo isset($item['name']) ? $item['name'] : ''; ?>" width="100"></td>
                        <td>Rs <?php echo isset($item['price']) ? $item['price'] : '0'; ?></td>
                        <td>
                            <a href="cart.php?action=decrease&id=<?php echo isset($item['id']) ? $item['id'] : ''; ?>" class="quantity-btn">-</a>
                            <?php echo isset($item['quantity']) ? $item['quantity'] : 0; ?>
                            <a href="cart.php?action=increase&id=<?php echo isset($item['id']) ? $item['id'] : ''; ?>" class="quantity-btn">+</a>
                        </td>
                        <td>Rs <?php echo isset($item['price']) && isset($item['quantity']) ? $item['price'] * $item['quantity'] : '0'; ?></td>
                        <td>
                            <a href="cart.php?action=remove&id=<?php echo isset($item['id']) ? $item['id'] : ''; ?>" class="remove-btn">Remove</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="total-container">
            <strong>Total Amount: Rs <?php echo $totalAmount; ?></strong>
        </div>
        <div class="total-container">
            <button class="proceed-btn">Proceed to Payment</button>
        </div>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>

</body>
</html>

<?php
$conn->close();
?>



payment 1
<?php
session_start();

// Initialize total amount from the cart
$totalAmount = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        if (isset($item['price'], $item['quantity'])) {
            $totalAmount += $item['price'] * $item['quantity'];
        }
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['payment_method'])) {
        $paymentMethod = $_POST['payment_method'];

        if ($paymentMethod == 'cash') {
            // Redirect to order confirmation or next page for cash on delivery
            header("Location: order_confirmation.php");
            exit();
        } elseif ($paymentMethod == 'wallet') {
            // Here you can open the user's digital wallet interface
            echo "<script>alert('Opening digital wallet...');</script>";
        } elseif ($paymentMethod == 'online') {
            // Generate a QR code for the specified amount (this is a placeholder)
            $qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?data=Amount:Rs{$totalAmount}&size=200x200";
            echo "<div style='text-align: center;'>";
            echo "<h3>Scan to Pay:</h3>";
            echo "<img src='{$qrCodeUrl}' alt='QR Code' />";
            echo "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 20px;
        }
        .payment-option {
            margin: 15px;
        }
        .submit-btn {
            background-color: #2ecc71;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .submit-btn:hover {
            background-color: #27ae60;
        }
    </style>
</head>
<body>

<h1>Select Payment Method</h1>
<form method="POST">
    <div class="payment-option">
        <label>
            <input type="radio" name="payment_method" value="cash" required>
            Cash on Delivery
        </label>
    </div>
    <div class="payment-option">
        <label>
            <input type="radio" name="payment_method" value="wallet" required>
            Digital Wallet
        </label>
    </div>
    <div class="payment-option">
        <label>
            <input type="radio" name="payment_method" value="online" required>
            Online Payment
        </label>
    </div>
    <button type="submit" class="submit-btn">Proceed</button>
</form>

</body>
</html>


payment 2
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('background.jpg') no-repeat center center/cover;
        }

        .form-container {
            background-color: #ffffff; /* White background for the form */
            padding: 20px;
            border-radius: 8px;
            width: 800px; /* Adjusted width for two columns */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            display: flex;
        }

        .details, .payment {
            width: 50%; /* Equal width for both sections */
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .section {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold; /* Bold labels */
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s; /* Smooth transition for border color */
        }

        input:focus, select:focus {
            border-color: #007BFF; /* Highlight border on focus */
            outline: none; /* Remove outline */
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s; /* Smooth transition for button color */
        }

        button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        /* Payment method icons */
        .payment-methods {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .payment-methods img {
            width: 50px;
            height: auto;
            margin: 0 10px; /* Added margin for spacing */
        }

        /* Combined section with gray background */
        .combined-section {
            background-color: #d3d3d3; /* Light gray background */
            padding: 20px;
            border-radius: 8px;
            display: flex;
            width: 100%; /* Full width */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Subtle shadow for the combined section */
            margin: auto;
        }
        /* Media query for responsive design */
        @media (max-width: 900px) {
            .form-container {
                flex-direction: column; /* Stack columns on smaller screens */
                width: 100%; /* Full width */
            }

            .details, .payment {
                width: 100%; /* Full width for both sections */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
           
            <div class="combined-section">
                <div class="details">
                    <h2>Details</h2>
                    <form action="/submit" method="post">
                        <div class="section">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" name="name" required>
                            
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                            
                            <label for="address">Address</label>
                            <input type="text" id="address" name="address" required>
                            
                            <label for="city">City</label>
                            <input type="text" id="city" name="city" required>

                            <label for="state">State</label>
                            <input type="text" id="state" name="state" required>

                            <label for="zip">ZIP</label>
                            <input type="text" id="zip" name="zip" required>

                            <label for="phone">Phone</label>
                            <input type="tel" id="phone" name="phone" required>
                        </div>
                </div>

                <div class="payment">
                    <h2>Payment</h2>
                    <div class="section">
                        
                    </div>

                    <div class="payment-methods">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/PayPal.svg/2560px-PayPal.svg.png" alt="PayPal">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png" alt="Visa">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/c/cb/Mastercard-logo.svg" alt="MasterCard">
                    </div>

                    <button type="submit">Proceed to Checkout</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>



updated menu.php file
<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to display the menu
function displayMenu($searchQuery = '') {
    global $conn;
    $sql = "SELECT * FROM menu" . ($searchQuery ? " WHERE name LIKE ?" : "");
    $stmt = $conn->prepare($sql);
    
    if ($searchQuery) {
        $searchParam = "%" . $searchQuery . "%";
        $stmt->bind_param("s", $searchParam);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<div class='card-container'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='card' data-id='" . $row['id'] . "'>";
            echo "<img src='../dataimg/" . $row["image"] . "' alt='" . $row["name"] . "' class='card-image'>";
            echo "<h2 class='card-title'>" . $row["name"] . "</h2>";
            echo "<p class='card-price'>Price: Rs: " . $row["price"] . "</p>";
            echo "<button class='add-to-cart'>Add to Cart</button>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No results found.</p>";
    }
}

// Handle search query
$searchQuery = isset($_GET['query']) ? $_GET['query'] : '';

// HTML and CSS
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order Menu</title>
    <style>
        body {
            background-image: url('../dataimg/background.jpeg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
        }

        .search-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        #search-bar {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 10px;
        }

        #search-button {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        #search-button:hover {
            background-color: #27ae60;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin: 0 auto;
            max-width: 1200px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card {
            width: 200px;
            height: 300px;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 10px;
            margin: 10px;
            display: inline-block;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
            position: relative; /* Set position to relative */
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-image {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }

        .card-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .card-price {
            font-size: 16px;
            color: #666;
        }

        .add-to-cart {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.2s ease-in-out;
        }

        .add-to-cart:hover {
            background-color: #27ae60;
        }

        .cart-button {
            position: fixed;
            top: 10px;
            right: 10px;
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.2s ease-in-out;
        }

        .cart-button:hover {
            background-color: #27ae60;
        }
    </style>
</head>
<body>

<!-- Search Bar -->
<div class="search-container">
    <input type="text" id="search-bar" placeholder="Search for food..." value="<?php echo htmlspecialchars($searchQuery); ?>">
    <button id="search-button">Search</button>
</div>

<!-- Cart Button -->
<a href="cart.php" class="cart-button">Cart (<span id="cart-count">0</span>)</a>

<!-- Menu Display -->
<?php displayMenu($searchQuery); ?>

<script>
    // Add event listener to add-to-cart buttons
    document.addEventListener("DOMContentLoaded", function() {
        const addToCartButtons = document.querySelectorAll(".add-to-cart");
        const cardContainer = document.querySelector(".card-container");

        addToCartButtons.forEach(button => {
            button.addEventListener("click", function(event) {
                event.stopPropagation(); // Prevent the click from bubbling up
                const card = this.closest('.card');
                const id = card.getAttribute("data-id");
                const xhr = new XMLHttpRequest();
                xhr.open("GET", "cart.php?action=add&id=" + id, true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Update cart count in the menu page
                            const cartCountElement = document.getElementById("cart-count");
                            cartCountElement.innerText = parseInt(cartCountElement.innerText) + 1;
                        }
                    }
                };
                xhr.send();
                // Redirect back to menu.php after adding to cart
                window.location.href = "menu.php";
            });
        });

        // Add event listener for clicks outside the card
        cardContainer.addEventListener("click", function(event) {
            const target = event.target.closest('.card');
            if (!target) {
                window.location.href = "menu.php"; // Redirect if click is outside of card
            }
        });

        // Add event listener to search button
        document.getElementById("search-button").addEventListener("click", function() {
            const query = document.getElementById("search-bar").value;
            if (query) {
                window.location.href = "?query=" + encodeURIComponent(query);
                // Reset search input after search
                document.getElementById("search-bar").value = '';
            }
        });

        // Add event listener for Enter key press in search bar
        document.getElementById("search-bar").addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                const query = this.value;
                if (query) {
                    window.location.href = "?query=" + encodeURIComponent(query);
                    // Reset search input after search
                    this.value = '';
                }
            }
        });
    });
</script>

</body>
</html>

<?php
$conn->close();
?>






PAYMENT  GATEWAY INTEGRATION


<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $price = $_POST['total_amount'];
    $upiID = 'mutkuleajinkya@okhdfcbank';
    $qrText = "upi://pay?pa=$upiID&am=$price&cu=INR";
} else {
    die("Invalid access");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Generator</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
</head>
<body>
    <h1>QR Code Generator</h1>
    <div id="qrcode"></div>

    <script>
        $(document).ready(function () {
            const qrText = "<?php echo $qrText; ?>"; // Get the QR text from PHP
            $('#qrcode').empty();
            new QRCode(document.getElementById("qrcode"), qrText);
        });
    </script>
</body>
</html>



Payment integration 2

<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it's not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

// Generate QR code if payment is initiated
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $price = $_POST['total_amount'] ?? $totalAmount; // Use POST amount or calculated total
    $upiID = 'mutkuleajinkya@okhdfcbank';
    $qrText = "upi://pay?pa=$upiID&am=$price&cu=INR";
} else {
    die("Invalid access");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('background.jpg') no-repeat center center/cover;
        }

        .form-container {
            background-color: #ffffff;
            /* White background for the form */
            padding: 20px;
            border-radius: 8px;
            width: 800px;
            /* Adjusted width for two columns */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            /* Subtle shadow */
            display: flex;
        }

        .details,
        .payment {
            width: 50%;
            /* Equal width for both sections */
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .section {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            /* Bold labels */
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s;
            /* Smooth transition for border color */
        }

        input:focus,
        select:focus {
            border-color: #007BFF;
            /* Highlight border on focus */
            outline: none;
            /* Remove outline */
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            /* Smooth transition for button color */
        }

        button:hover {
            background-color: #0056b3;
            /* Darker blue on hover */
        }

        /* Payment method icons */
        .payment-methods {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .payment-methods img {
            width: 50px;
            height: auto;
            margin: 0 10px;
            /* Added margin for spacing */
        }

        /* Combined section with gray background */
        .combined-section {
            background-color: #d3d3d3;
            /* Light gray background */
            padding: 20px;
            border-radius: 8px;
            display: flex;
            width: 100%;
            /* Full width */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            /* Subtle shadow for the combined section */
            margin: auto;
        }

        /* Media query for responsive design */
        @media (max-width: 900px) {
            .form-container {
                flex-direction: column;
                /* Stack columns on smaller screens */
                width: 100%;
                /* Full width */
            }

            .details,
            .payment {
                width: 100%;
                /* Full width for both sections */
            }
        }

        .qrcode {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-container">
            <div class="details">
                <h2>Details</h2>
                <form action="" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo $totalAmount; ?>">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" required>

                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>

                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" required>

                    <label for="city">City</label>
                    <input type="text" id="city" name="city" required>

                    <label for="state">State</label>
                    <input type="text" id="state" name="state" required>

                    <label for="zip">ZIP</label>
                    <input type="text" id="zip" name="zip" required>

                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="payment">
                <h2>Payment</h2>
                <div id="qrcode" class="qrcode"></div>
                <script>
                    $(document).ready(function() {
                        const qrText = "<?php echo isset($qrText) ? $qrText : ''; ?>"; // Get the QR text from PHP
                        if (qrText) {
                            $('#qrcode').empty();
                            new QRCode(document.getElementById("qrcode"), qrText);
                        }
                    });
                </script>

                <button type="submit">Proceed to Checkout</button>
            </div>
            </form>
        </div>
    </div>
</body>

</html>