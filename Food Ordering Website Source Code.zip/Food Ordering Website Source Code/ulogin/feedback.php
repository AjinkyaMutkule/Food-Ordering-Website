
<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $feedback = $_POST['feedback'];
    $user_id = $_SESSION['uid'];

    // Connect to database
    $conn = new mysqli("localhost", "root", "", "foods");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert feedback into the database
    $stmt = $conn->prepare("INSERT INTO report (userid, name, email, feedback) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        echo "Error preparing statement: " . $conn->error;
    } else {
        $stmt->bind_param("isss", $user_id, $name, $email, $feedback);
        if ($stmt->execute()) {
            echo "Thank you for your feedback!";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    $conn->close();
}
?>