<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Status Tracker</title>
    <style>
   
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    color: #333;
}

.container {
    width: 80%;
    max-width: 1000px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    text-align: center;
}

h1 {
    color: #2c3e50;
    margin-bottom: 40px;
    font-size: 36px;
}

/* Progress Line Container */
.line-container {
    position: relative;
    width: 100%;
    height: 8px;
    background-color: #e0e0e0;
    border-radius: 5px;
    margin-bottom: 40px;
    overflow: hidden;
}

.progress-line {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    background-color: #3498db;
    width: 0;
    transition: width 0.5s ease;
}

.delivery-boy {
    position: absolute;
    top: -40px;
    left: 0;
    transition: left 0.5s ease;
}

.delivery-boy img {
    width: 60px;
}

/* Tracker Stages */
.tracker {
    display: flex;
    justify-content: space-between;
    margin-bottom: 40px;
}

.stage {
    width: 24%;
    text-align: center;
    position: relative;
    font-size: 18px;
    color: #7f8c8d;
    font-weight: 600;
    transition: color 0.5s ease;
}

.stage.active {
    color: #3498db;
}

.stage .icon {
    width: 48px;
    height: 48px;
    background-size: cover;
    margin: 0 auto 10px;
}

/* Feedback Form */
.feedback-container {
    margin-bottom: 40px;
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.feedback-container h2 {
    font-size: 26px;
    color: #2c3e50;
    margin-bottom: 20px;
}

.form-group {
    margin-bottom: 20px;
    text-align: left;
}

.form-group label {
    font-size: 18px;
    display: block;
    margin-bottom: 5px;
}

.form-group input, .form-group textarea {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-group textarea {
    resize: vertical;
}

.submit-btn {
    background-color: #27ae60;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 18px;
    transition: background-color 0.3s ease;
}

.submit-btn:hover {
    background-color: #219150;
}

/* Back Button */
.back-btn {
    background-color: #f39c12;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 18px;
    transition: background-color 0.3s ease;
}

.back-btn:hover {
    background-color: #e67e22;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        width: 95%;
        padding: 15px;
    }

    h1 {
        font-size: 28px;
    }

    .stage {
        font-size: 14px;
    }

    .submit-btn, .back-btn {
        font-size: 16px;
        padding: 8px 15px;
    }

    .feedback-container h2 {
        font-size: 22px;
    }
}

    </style>
</head>
<body>

<div class="container">
    <h1>Order Status Tracker</h1>

    <!-- Delivery Boy on Progress Line -->
    <div class="line-container">
        <div class="progress-line" id="progress-line"></div>
        <div class="delivery-boy" id="delivery-boy">
            <img src="https://img.icons8.com/fluency/96/000000/delivery-scooter.png" alt="Delivery Boy on Bike">
        </div>
    </div>

    <div class="tracker">
        <div class="stage active">
            <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/sent.png');"></div>
            Sent
        </div>
        <div class="stage">
            <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/checked.png');"></div>
            Confirmed
        </div>
        <div class="stage">
            <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/scooter.png');"></div>
            On The Way
        </div>
        <div class="stage">
            <div class="icon" style="background-image: url('https://img.icons8.com/fluency/48/000000/delivered-box.png');"></div>
            Delivered
        </div>
    </div>

    <div class="feedback-container">
        <h2>Feedback Form</h2>
        <form action="feedback.php" method="POST">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="feedback">Your Feedback:</label>
                <textarea id="feedback" name="feedback" rows="3" required></textarea>
            </div>
            <button type="submit" class="submit-btn">Submit Feedback</button>
        </form>
    </div>
    
   
    <button class="back-btn" onclick="window.location.href='../index.php'">Back to Home</button>
</div>

<script>
    const stages = document.querySelectorAll('.stage');
    const progressLine = document.getElementById('progress-line');
    const deliveryBoy = document.getElementById('delivery-boy');

   
    function updateProgress(stageIndex) {
        stages.forEach((stage, index) => {
            if (index <= stageIndex) {
                stage.classList.add('active');
            } else {
                stage.classList.remove('active');
            }
        });

        
        const progressPercentage = (stageIndex + 1) * 25; 
        progressLine.style.width = progressPercentage + '%';

        
        deliveryBoy.style.left = progressPercentage + '%';
    }

    
    setTimeout(() => updateProgress(0), 90000); 
    setTimeout(() => updateProgress(1), 180000); 
    setTimeout(() => updateProgress(2), 360000); 
    setTimeout(() => updateProgress(3), 720000); 
</script>

</body>
</html>
