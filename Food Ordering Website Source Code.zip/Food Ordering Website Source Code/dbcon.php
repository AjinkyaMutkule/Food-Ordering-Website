<?php
	
	$conn = mysqli_connect('localhost','root','','foods');

	if ($conn == false) 
	{
		echo "Database connection failed";
	}
?>