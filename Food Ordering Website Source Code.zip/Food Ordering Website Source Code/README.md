<h1 align="center"> Online-Food-Ordering-System </h1>

Online Food Ordering System Website using basic PHP, SQL, HTML & CSS. You can use any one of XAMPP, WAMP or LAMP server to run the Web App on your local machine. It has a food ordering module for a customer. It also provides menu, orders and user management module for admin.

<hr>

Admin Login & Password (You can change this in phpmyadmin): <br>
Login: admin <br>
Password: admin <br>

## Screenshots

<img src="https://github.com/nilesh-kawar/Online-Food-Ordering-System/blob/main/screenshots/home.png"/>

Find how the project looks in screenshots folder Or <a href="https://github.com/nilesh-kawar/Online-Food-Ordering-System/blob/main/screenshots/"> click here </a>

## Technologies Used

<ul>
  <li>HTML</li>
  <li>CSS</li>
  <li>Javascript</li>
  <li>Bootstrap</li>
  <li>PHP</li>
  <li>MySQL</li>
</ul>

## Tools Used
<ul>
  <li>XAMPP</li>
</ul>

## How to Install and Use
1. Download and install XAMPP/WAMP/LAMP server and download the files of this project
2. Copy the folder of this project in your xampp/htdocs/www folder
3. Start XAMMP. Start Apache and SQL server. Go to phpmyadmin and create a new database named 'food'
4. Go to the food database created and click on 'Import' option in the top menu
5. Upload the jhatpat-foods.sql file and import it
6. Open your web browser and check if you got the website running on your localhost (http://localhost:8080/www/)

<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create a page for menu of a food order site
function displayMenu() {
    global $conn;
    $sql = "SELECT * FROM menu";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div class='card-container'>";
        while($row = $result->fetch_assoc()) {
            echo "<div class='card'>";
            echo "<img src='../dataimg/" . $row["image"] . "' alt='" . $row["name"] . "' class='card-image'>";
            echo "<h2 class='card-title'>" . $row["name"]. "</h2>";
            echo "<p class='card-price'>Price: Rs :" . $row["price"]. "</p>";
            echo "<button class='order-now'>Order Now</button>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "0 results";
    }
}

function searchMenu() {
    global $conn;
    echo "<div class='search-menu'>";
    echo "<input type='text' id='search-input' placeholder='Search menu...'>";
    echo "<button id='search-button'>Search</button>";
    echo "<div id='search-results'></div>";
    echo "</div>";

    echo "<script>
        document.getElementById('search-button').addEventListener('click', function() {
            var searchInput = document.getElementById('search-input').value;
            var searchResults = document.getElementById('search-results');

            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'search.php?search=' + searchInput, true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    searchResults.innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        });
    </script>";
}

searchMenu();
displayMenu();

$conn->close();
?>
<style>
    body {
        background-image: url('../dataimg/background.jpeg');
        background-size: cover;
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
    }

    .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin: 0 auto;
        max-width: 1200px;
        background-color: rgba(255, 255, 255, 0.8);
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .card {
        width: 200px;
        height: 300px;
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 10px;
        margin: 10px;
        display: inline-block;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease-in-out;
    }

    .card:hover {
        transform: scale(1.05);
    }

    .card-image {
        width: 100%;
        height: 150px;
        object-fit: cover;
        border-radius: 10px 10px 0 0;
    }

    .card-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .card-price {
        font-size: 16px;
        color: #666;
    }

    .order-now {
        background-color: #2ecc71;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.2s ease-in-out;
    }

    .order-now:hover {
        background-color: #27ae60;
    }

    .search-menu {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background-color: #333;
        color: #fff;
        padding: 10px;
        text-align: center;
    }

    #search-input {
        width: 50%;
        height: 30px;
        padding: 10px;
        font-size: 16px;
        border: none;
        border-radius: 5px;
    }

    #search-button {
        background-color: #2ecc71;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.2s ease-in-out;
    }

    #search-button:hover {
        background-color: #27ae60;
    }

    #search-results {
        margin-top: 20px;
    }
</style>
```

Create a new file named `search.php` and add the following code:

```php
<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "foods");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search = $_GET['search'];

$sql = "SELECT * FROM menu WHERE name LIKE '%$search%'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='card'>";
        echo "<img src='../dataimg/" . $row["image"] . "' alt='" . $row["name"] . "' class='card-image'>";
        echo "<h2 class='card-title'>" . $row["name"]. "</h2>";
        echo "<p class='card-price'>Price: Rs :" . $row["price"]. "</p>";
        echo "<button class='order-now'>Order Now</button>";
        echo "</div>";
    }
} else {
    echo "0 results";
}

$conn->close();
?>


CART >PHP

<?php
session_start();

if (isset($_SESSION["uid"])) {
    $uid = $_SESSION["uid"];
}

$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it's not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']); // Ensure $itemId is an integer

    // Use prepared statements for security
    $stmt = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
    $stmt->close();
}

// Store cart details in the cart table when checkout is clicked
if (isset($_POST['submit'])) {
    if (!empty($_SESSION['cart'])) { // Ensure the cart is not empty
        foreach ($_SESSION['cart'] as $item) {
            // Only proceed if the item is in the cart
            if (isset($item['id'], $item['name'], $item['price'], $item['quantity'])) {
                $userId = $_SESSION['uid'];
                $itemId = $item['id'];
                $itemName = $item['name'];
                $itemPrice = $item['price'];
                $quantity = $item['quantity'];
                $total = $itemPrice * $quantity;

                // Insert cart details into the cart table
                $stmt = $conn->prepare("INSERT INTO cart (user_id, item_id, item_name, item_price, quantity, total) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("iisdis", $userId, $itemId, $itemName, $itemPrice, $quantity, $total);
                $stmt->execute();
                $stmt->close();
            }
        }

        // Clear the cart after inserting into the database
        $_SESSION['cart'] = array();

        // Redirect to a success or confirmation page
        header("Location: success.php");
        exit;
    } else {
        echo "<script>alert('Your cart is empty. Please add items to your cart before checking out.');</script>";
    }
}

// Update quantity of the item
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        // Increase or decrease quantity based on the action
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <!-- Back Button -->
    <a href="menu.php" class="back-btn">Back to Menu</a>

    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td><?php echo isset($item['id']) ? htmlspecialchars($item['id']) : 'N/A'; ?></td>
                            <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                            <td><img src="../dataimg/<?php echo isset($item['image']) ? htmlspecialchars($item['image']) : ''; ?>" alt="<?php echo isset($item['name']) ? htmlspecialchars($item['name']) : ''; ?>" width="100"></td>
                            <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=decrease&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">-</a>
                                <?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : 0; ?>
                                <a href="cart.php?action=increase&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="quantity-btn">+</a>
                            </td>
                            <td>Rs <?php echo isset($item['price']) && isset($item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                            <td>
                                <a href="cart.php?action=remove&id=<?php echo isset($item['id']) ? urlencode($item['id']) : ''; ?>" class="remove-btn">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-container">
                <strong>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></strong>
            </div>
            <div class="total-container">
                <form action="cart.php" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                    <button type="submit" class="proceed-btn" name="submit">Checkout >></button>
                </form>
            </div>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
CART 1> 
<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION["uid"])) {
    $uid = $_SESSION["uid"];
} else {
    die("User is not logged in.");
}

$conn = new mysqli("localhost", "root", "", "foods");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);  // Ensure $itemId is an integer

    // Use prepared statements to fetch the item details
    $stmt = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    if ($stmt === false) {
        die("SQL error: " . $conn->error);  // Handle SQL error
    }

    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
    $stmt->close();
}

// Store cart details in the `cart1` table when checkout is clicked
if (isset($_POST['submit'])) {
    if (!empty($_SESSION['cart'])) {
        // Initialize the variable to hold the formatted cart items
        $cartItemsFormatted = '';

        foreach ($_SESSION['cart'] as $item) {
            if (isset($item['name'], $item['quantity'], $item['price'])) {
                // Format item data as "item_name->quantity->price"
                $cartItemsFormatted .= $item['name'] . '->' . $item['quantity'] . '->' . $item['price'] . ', ';
            }
        }

        // Remove the last comma and space
        $cartItemsFormatted = rtrim($cartItemsFormatted, ', ');

        // Prepare to insert into the cart1 table
        $userId = $_SESSION['uid'];
        $total = array_sum(array_map(function($item) {
            return $item['price'] * $item['quantity'];
        }, $_SESSION['cart']));

        // Insert into the cart1 table
        $stmt = $conn->prepare("INSERT INTO cart1 (user_id, item_details, total) VALUES (?, ?, ?)");
        if ($stmt === false) {
            die("SQL error: " . $conn->error);  // Handle SQL error
        }

        // Ensure correct types are used
        $stmt->bind_param("isd", $userId, $cartItemsFormatted, $total);
        $stmt->execute();
        $stmt->close();

        // Clear the cart after checkout
        $_SESSION['cart'] = array();

        // Redirect to checkout.php after inserting data
        header("Location: checkout.php");
        exit();
    } else {
        echo "<script>alert('Your cart is empty. Please add items before checking out.');</script>";
    }
}

// Update item quantity in the cart
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove the item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <!-- Back Button -->
    <a href="menu.php" class="back-btn">Back to Menu</a>

    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['id']); ?></td>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td><img src="../dataimg/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" width="100"></td>
                            <td>Rs <?php echo htmlspecialchars($item['price']); ?></td>
                            <td>
                                <a href="cart.php?action=decrease&id=<?php echo urlencode($item['id']); ?>" class="quantity-btn">-</a>
                                <?php echo htmlspecialchars($item['quantity']); ?>
                                <a href="cart.php?action=increase&id=<?php echo urlencode($item['id']); ?>" class="quantity-btn">+</a>
                            </td>
                            <td>Rs <?php echo htmlspecialchars($item['price'] * $item['quantity']); ?></td>
                            <td>
                                <a href="cart.php?action=remove&id=<?php echo urlencode($item['id']); ?>" class="remove-btn">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-container">
                <strong>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></strong>
            </div>
            <div class="total-container">
                <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                    <button type="submit" class="proceed-btn" name="submit">Checkout >></button>
                </form>
            </div>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>


CART FIX

<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION["uid"])) {
    $uid = $_SESSION["uid"];
} else {
    die("User is not logged in.");
}

$conn = new mysqli("localhost", "root", "", "foods");

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add item to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);  // Ensure $itemId is an integer

    // Use prepared statements to fetch the item details
    $stmt = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    if ($stmt === false) {
        die("SQL error: " . $conn->error);  // Handle SQL error
    }

    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // If the item is already in the cart, increase the quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            // Add item to the cart
            $_SESSION['cart'][$itemId] = array(
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'image' => $item['image'],
                'quantity' => 1
            );
        }
    }
    $stmt->close();
}

// Store cart details in the `cart1` table when checkout is clicked
if (isset($_POST['submit'])) {
    if (!empty($_SESSION['cart'])) {
        // Initialize the variable to hold the formatted cart items
        $cartItemsFormatted = '';

        foreach ($_SESSION['cart'] as $item) {
            if (isset($item['name'], $item['quantity'], $item['price'])) {
                // Format item data as "item_name->quantity->price"
                $cartItemsFormatted .= $item['name'] . '->' . $item['quantity'] . '->' . $item['price'] . ', ';
            }
        }

        // Remove the last comma and space
        $cartItemsFormatted = rtrim($cartItemsFormatted, ', ');

        // Prepare to insert into the cart1 table
        $userId = $_SESSION['uid'];
        $total = array_sum(array_map(function($item) {
            return $item['price'] * $item['quantity'];
        }, $_SESSION['cart']));

        // Insert into the cart1 table
        $stmt = $conn->prepare("INSERT INTO cart1 (user_id, item_details, total) VALUES (?, ?, ?)");
        if ($stmt === false) {
            die("SQL error: " . $conn->error);  // Handle SQL error
        }

        // Ensure correct types are used
        $stmt->bind_param("isd", $userId, $cartItemsFormatted, $total);
        $stmt->execute();
        $stmt->close();

        // Clear the cart after checkout
        $_SESSION['cart'] = array();

        // Redirect to checkout.php after inserting data
        header("Location: Checkout.php");
        exit();
    } else {
        echo "<script>alert('Your cart is empty. Please add items before checking out.');</script>";
    }
}

// Update item quantity in the cart
if (isset($_GET['action']) && ($_GET['action'] == 'increase' || $_GET['action'] == 'decrease') && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$itemId])) {
        if ($_GET['action'] == 'increase') {
            $_SESSION['cart'][$itemId]['quantity']++;
        } elseif ($_GET['action'] == 'decrease') {
            if ($_SESSION['cart'][$itemId]['quantity'] > 1) {
                $_SESSION['cart'][$itemId]['quantity']--;
            } else {
                // Remove the item if quantity becomes 0
                unset($_SESSION['cart'][$itemId]);
            }
        }
    }
}

// Remove item from cart
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $itemId = intval($_GET['id']);
    if (isset($_SESSION['cart'][$itemId])) {
        unset($_SESSION['cart'][$itemId]);
    }
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <!-- Back Button -->
    <a href="menu.php" class="back-btn">Back to Menu</a>

    <div class="cart-container">
        <h1>Your Cart</h1>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['id']); ?></td>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td><img src="../dataimg/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" width="100"></td>
                            <td>Rs <?php echo htmlspecialchars($item['price']); ?></td>
                            <td>
                                <a href="cart.php?action=decrease&id=<?php echo urlencode($item['id']); ?>" class="quantity-btn">-</a>
                                <?php echo htmlspecialchars($item['quantity']); ?>
                                <a href="cart.php?action=increase&id=<?php echo urlencode($item['id']); ?>" class="quantity-btn">+</a>
                            </td>
                            <td>Rs <?php echo htmlspecialchars($item['price'] * $item['quantity']); ?></td>
                            <td>
                                <a href="cart.php?action=remove&id=<?php echo urlencode($item['id']); ?>" class="remove-btn">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="total-container">
                <strong>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></strong>
            </div>
            <div class="total-container">
                <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
                    <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($totalAmount); ?>">
                    <button type="submit" class="proceed-btn" name="submit">Checkout</button>
                </form>
            </div>
        <?php else: ?>
           
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>

Checkout FIX

<?php
// Start session
session_start();

if (isset($_SESSION["uid"])) {
    $uid = $_SESSION["uid"];
}
// Connect to database
$conn = mysqli_connect("localhost", "root", "", "foods");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if user is logged in
if (!isset($_SESSION['uid'])) {
    header('Location: login.php');
    exit;
}
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty!";
    exit();
}

// Fetch the cart items from the session
$cartItems = $_SESSION['cart'];

// Calculate the total amount
$totalAmount = 0;
foreach ($cartItems as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

// Get user data from admin/customerdb.php
$query = "SELECT * FROM user WHERE id = '" . $_SESSION['uid'] . "'";
$result = mysqli_query($conn, $query);
if ($result) {
    $customer_data = mysqli_fetch_assoc($result);
} else {
    echo "Error: " . mysqli_error($conn);
}

// Get cart data from cart.php
$cart_query = "SELECT * FROM cart WHERE id = '" . $_SESSION['uid'] . "'";
$cart_result = mysqli_query($conn, $cart_query);
if ($cart_result) {
    $cart_data = array();
    while ($row = mysqli_fetch_assoc($cart_result)) {
        $cart_data[] = $row;
    }
} else {
    echo "Error: " . mysqli_error($conn);
}

// Check if cart data is available
if (!isset($cart_data) || empty($cart_data)) {
    $cart_data = array();
}

if (isset($_POST['order'])) {
    $name = $customer_data['name'];
    $phone = $customer_data['mobile'];
    $total_amount = $totalAmount;
    $payment_method = $_POST['payment_method'];

    $stmt = $conn->prepare("INSERT INTO payment (name, phone, payment_method, total_amount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssd", $name, $phone, $payment_method, $total_amount);
    $stmt->execute();
    $stmt->close();
}

// Calculate subtotal and total
$subtotal = 0;
foreach ($cart_data as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: black;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
        }

        .account-details,
        .cart-summary,
        .payment-details {
            border: 1px solid #d3d3d3;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .account-details {
            text-align: center;
        }

        .account-details button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .account-details button:hover {
            background-color: #45a049;
        }

        .Ordernow button:hover {
            background-color: #45a049;

        }

        .Ordernow button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .summary-container {
            display: flex;
            justify-content: space-between;
        }

        .cart-summary,
        .payment-details {
            width: 48%;
        }

        h2 {
            text-align: center;
            margin-top: 0;
            color: #333;
        }

        p {
            margin: 10px 0;
        }

        .price-details {
            font-weight: bold;
            color: #4CAF50;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="account-details">
            <h2>Account Details</h2>
            <p><strong>Name:</strong> <?php echo $customer_data['name']; ?></p>
            <p><strong>Mobile No.:</strong> <?php echo $customer_data['mobile']; ?></p>
            <p><strong>Email:</strong> <?php echo $customer_data['email']; ?></p>
            <p><strong>Address:</strong> <?php echo $customer_data['address']; ?></p>
            <button>Change Address</button>
        </div>
        <div class="clearfix">
            <div class="left">
                <div class="cart-summary">
                    <h2>Cart Summary</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cartItems as $item): ?>
                                <tr>
                                    <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                                    <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                                    <td><?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : '0'; ?></td>
                                    <td>Rs <?php echo isset($item['price'], $item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="payment-details">
                    <h2>Payment Details</h2>
                    <p><strong>Payment Method:</strong></p>
                    <form action="" method="POST">
                        <input type="radio" id="cod" name="payment_method" value="Cash on Delivery (COD)">
                        <label for="cod">Cash on Delivery (COD)</label><br>
                        <input type="radio" id="upi" name="payment_method" value="UPI">
                        <label for="upi">UPI</label><br>
                        <input type="radio" id="digital_wallet" name="payment_method" value="Digital Wallet" onclick="upiQR()">
                        <label for="digital_wallet">Digital Wallet</label><br>
                        <p><strong>Amount Payable: Rs <?php echo $totalAmount; ?></strong></p>
                    </form>
                </div>
				<center><button name="order" onclick="location.href='bill.php'">Order Now</button></center>
            </div>
            <div class="right">
                <div class="qrcode"></div>
            </div>
        </div>
    </div>

    <script>
        function upiQR() {
            $('#priceForm').on('submit', function(e) {
                e.preventDefault();
                const priceInput = $('#service');
                const price = priceInput.val().trim();
                const upiID = 'mutkuleajinkya@okhdfcbank';
                const qrText = `upi://pay?pa=${upiID}&am=${price}&cu=INR`;
                $('#qrcode').empty();
                new QRCode(document.getElementById("qrcode"), qrText);
            });
        };
    </script>

</body>

</html>

BILL FIX 

<?php
session_start();
$conn = new mysqli("localhost", "root", "", "foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty!";
    exit();
}

// Fetch the cart items from the session
$cartItems = $_SESSION['cart'];

// Calculate the total amount
$totalAmount = 0;
foreach ($cartItems as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

// Fetch user details from the user table
$userName = $userAddress = $orderDate = '';
$userId = $_SESSION['uid']; // Assuming user ID is stored in the session

$sql = "SELECT name, address FROM user WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $userId); // Bind the user ID as an integer
    $stmt->execute();
    $stmt->bind_result($userName, $userAddress);
    $stmt->fetch();
    $stmt->close();
}

// Get the current date and time for the order date
$orderDate = date('d-m-y H:i:s');

// Generate a unique bill number
$billNumber = rand(2002, 3402);

// Insert the order into the database using prepared statements
$sql = "INSERT INTO bill (bill_number, user_name, user_address, order_date, total_amount) VALUES (?, ?, ?, ?, ?)";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param('ssssd', $billNumber, $userName, $userAddress, $orderDate, $totalAmount);
    $stmt->execute();
    $stmt->close();
}

// Insert each item into the bill_items table
$sql = "INSERT INTO bill_items (bill_number, item_name, price, quantity) VALUES (?, ?, ?, ?)";
if ($stmt = $conn->prepare($sql)) {
    foreach ($cartItems as $item) {
        $stmt->bind_param('sssd', $billNumber, $item['name'], $item['price'], $item['quantity']);
        $stmt->execute();
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }

        .bill-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            color: #5D5C61;
        }

        .user-details {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #5D5C61;
            border-radius: 4px;
            background-color: #f9f9f9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th,
        table td {
            border: 1px solid #5D5C61;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #5D5C61;
            color: white;
        }

        .total-amount {
            text-align: right;
            font-size: 1.2em;
            margin-top: 20px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 0.9em;
            color: #888;
        }

        .back-btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #5D5C61;
            color: white;
            text-decoration: none;
            text-align: center;
            border-radius: 4px;
        }

        .back-btn:hover {
            background-color: #4b4a4d;
        }
    </style>
</head>

<body>
    <div class="bill-container">
        <h1>Bill</h1>

        <!-- User Details -->
        <div class="user-details">
            <p><strong>Bill Number:</strong> <?php echo htmlspecialchars($billNumber); ?></p>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($userName); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($userAddress); ?></p>
            <p><strong>Date:</strong> <?php echo htmlspecialchars($orderDate); ?></p>
        </div>

        <!-- Order Details -->
        <h2>Order Summary</h2>
        <table>
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                        <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                        <td><?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : '0'; ?></td>
                        <td>Rs <?php echo isset($item['price'], $item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Total Amount -->
        <div class="total-amount">
            <h3>Total Amount: Rs <?php echo htmlspecialchars($totalAmount); ?></h3>
        </div>

        <!-- Footer Section (if required) -->
        <div class="footer">
            <p>Thank you for ordering with us!</p>
        </div>

        <!-- Back Button to return to menu -->
        <a href="menu.php" class="back-btn">Back to Menu</a>
    </div>
</body>

</html>
Checkout order_confer
<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['uid'])) {
    header('Location: login.php');
    exit;
}

// Connect to database
$conn = mysqli_connect("localhost", "root", "", "foods");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty!";
    exit();
}

// Fetch the cart items from the session
$cartItems = $_SESSION['cart'];

// Calculate the total amount
$totalAmount = 0;
foreach ($cartItems as $item) {
    if (isset($item['price'], $item['quantity'])) {
        $totalAmount += $item['price'] * $item['quantity'];
    }
}

// Get user data from user table
$query = "SELECT * FROM user WHERE id = '" . $_SESSION['uid'] . "'";
$result = mysqli_query($conn, $query);
if ($result) {
    $customer_data = mysqli_fetch_assoc($result);
} else {
    echo "Error: " . mysqli_error($conn);
}

// Initialize cart data
$cart_data = [];

// Process order when 'Order Now' button is clicked
if (isset($_POST['order'])) {
    $name = $customer_data['name'];
    $phone = $customer_data['mobile'];
    $payment_method = $_POST['payment_method'];

    // Prepare to insert payment details
    $stmt = $conn->prepare("INSERT INTO payment (name, phone, payment_method, total_amount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssd", $name, $phone, $payment_method, $totalAmount);
    
    if ($stmt->execute()) {
        // Clear the cart after successfully placing the order
        $_SESSION['cart'] = [];
        header("Location: order_confirmation.php"); // Redirect to an order confirmation page
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: black;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
        }

        .account-details,
        .cart-summary,
        .payment-details {
            border: 1px solid #d3d3d3;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .account-details {
            text-align: center;
        }

        .account-details button,
        .Ordernow button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .account-details button:hover,
        .Ordernow button:hover {
            background-color: #45a049;
        }

        h2 {
            text-align: center;
            margin-top: 0;
            color: #333;
        }

        .summary-container {
            display: flex;
            justify-content: space-between;
        }

        .cart-summary,
        .payment-details {
            width: 48%;
        }

        p {
            margin: 10px 0;
        }

        .price-details {
            font-weight: bold;
            color: #4CAF50;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="account-details">
            <h2>Account Details</h2>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($customer_data['name']); ?></p>
            <p><strong>Mobile No.:</strong> <?php echo htmlspecialchars($customer_data['mobile']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($customer_data['email']); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($customer_data['address']); ?></p>
            <button>Change Address</button>
        </div>
        <div class="cart-summary">
            <h2>Cart Summary</h2>
            <table border="1">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cartItems as $item): ?>
                        <tr>
                            <td><?php echo isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A'; ?></td>
                            <td>Rs <?php echo isset($item['price']) ? htmlspecialchars($item['price']) : '0'; ?></td>
                            <td><?php echo isset($item['quantity']) ? htmlspecialchars($item['quantity']) : '0'; ?></td>
                            <td>Rs <?php echo isset($item['price'], $item['quantity']) ? htmlspecialchars($item['price'] * $item['quantity']) : '0'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="payment-details">
            <h2>Payment Details</h2>
            <form action="" method="POST">
                <p><strong>Payment Method:</strong></p>
                <input type="radio" id="cod" name="payment_method" value="Cash on Delivery (COD)">
                <label for="cod">Cash on Delivery (COD)</label><br>
                <input type="radio" id="upi" name="payment_method" value="UPI">
                <label for="upi">UPI</label><br>
                <input type="radio" id="digital_wallet" name="payment_method" value="Digital Wallet">
                <label for="digital_wallet">Digital Wallet</label><br>
                <p><strong>Amount Payable: Rs <?php echo $totalAmount; ?></strong></p>
                <center><button name="order">Order Now</button></center>
            </form>
        </div>
    </div>
</body>

</html>
