<?php
include('../dbcon.php'); // Including the database connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <style type="text/css">
        /* Styling for buttons and layout */
        .abc button {
            width: 350px;
            font-size: 20px;
        }
        table {
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: black;
            color: white;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <div align="center" class="bg-dark text-light pt-4 pb-4">
        <a href="../logout.php">
            <button style="float: right;" class="btn btn-danger mr-3">LOGOUT</button>
        </a>
        <a href="admindash.php">
            <button style="float: left;" class="btn btn-success ml-3"><< BACK</button>
        </a>
        <h1>ORDER DETAILS</h1>
    </div>

    <!-- Orders Table -->
    <table align="center" border="1" width="90%" class="mb-5">
        <tr>
            <th width="100">User Id</th>
            <th width="150">User Name</th>
            <th width="150">Email</th>
            <th width="150">Address</th>
            <th width="180">Payment Mode</th>
            <th width="180">Item Details</th>
        </tr>

        <?php
       
	   // Assuming this is where the issue occurs
	   $query = "SELECT * FROM `orders`";
	   $run = mysqli_query($conn, $query);
	   
	   if (mysqli_num_rows($run) < 1) {
		   echo "<tr><td colspan='10' align='center'>No data found</td><tr>";
	   } else {
		   while ($data = mysqli_fetch_assoc($run)) {
			   ?>
			   <tr align="center">
				   <td> <?php echo isset($data['userId']) ? htmlspecialchars($data['userId']) : 'N/A'; ?> </td>
				   <td> <?php echo isset($data['user_name']) ? htmlspecialchars($data['user_name']) : 'N/A'; ?> </td>
				   <td> <?php echo isset($data['email']) ? htmlspecialchars($data['email']) : 'N/A'; ?> </td>
				   <td> <?php echo isset($data['address']) ? htmlspecialchars($data['address']) : 'N/A'; ?> </td>
				   <td> <?php echo isset($data['payment_mode']) ? htmlspecialchars($data['payment_mode']) : 'N/A'; ?> </td>
				   <td> <?php echo isset($data['items_details']) ? htmlspecialchars($data['items_details']) : 'N/A'; ?> </td>
			   </tr>
			   <?php
		   }
	   }
	   ?>
	   
           
        <?php
            
        
        ?>
    </table>

    <!-- Scripts -->
    <script src="bootstrap/jss/jquery.min.js"></script>
    <script src="bootstrap/jss/popper.min.js"></script>
    <script src="bootstrap/jss/bootstrap.min.js"></script>
</body>
</html>
