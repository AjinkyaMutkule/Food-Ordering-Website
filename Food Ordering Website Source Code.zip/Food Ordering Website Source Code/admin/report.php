<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "foods";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM report";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Feedback Report</title>
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f8f9fa;
      padding: 20px;
    }
    table {
      width: 100%;
      margin-top: 20px;
      border-collapse: collapse;
    }
    th, td {
      padding: 12px;
      text-align: center;
      border: 1px solid #dee2e6;
    }
    th {
      background-color: #343a40;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    tr:hover {
      background-color: #ddd;
    }
    h1 {
      margin-bottom: 20px;
      color: #343a40;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>Feedback Report</h1>
    
    <?php
    if ($result->num_rows > 0) {
      echo "<table class='table table-bordered table-striped'>";
      echo "<tr><th>ID</th><th>User ID</th><th>Name</th><th>Email</th><th>Feedback</th></tr>";
      while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"] . "</td><td>" . $row["userid"] . "</td><td>" . $row["Name"] . "</td><td>" . $row["email"] . "</td><td>" . $row["feedback"] . "</td></tr>";
      }
      echo "</table>";
    } else {
      echo "<div class='alert alert-warning'>No results found.</div>";
    }

    $conn->close();
    ?>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
